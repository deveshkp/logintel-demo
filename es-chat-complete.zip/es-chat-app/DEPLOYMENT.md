# Deployment Guide

This guide covers deploying the Elasticsearch Chat application to production.

## Prerequisites

- Docker & Docker Compose
- On-premises Elasticsearch 9.3.0 Platinum with SSL
- MongoDB on-premises with SSL
- Azure Entra AD tenant
- SSL certificates for all services
- Linux server (Ubuntu 20.04+ recommended)

## Pre-Deployment Checklist

- [ ] Elasticsearch cluster is accessible and healthy
- [ ] MongoDB is accessible and has SSL enabled
- [ ] Azure Entra AD app registration is created
- [ ] SSL certificates are obtained and validated
- [ ] Firewall rules allow necessary ports
- [ ] Backup strategy is in place
- [ ] Monitoring and logging are configured

## Production Environment Setup

### 1. Prepare SSL Certificates

```bash
# Create certificate directory
mkdir -p /etc/es-chat/certs

# Copy Elasticsearch CA certificate
cp /path/to/elasticsearch-ca.crt /etc/es-chat/certs/

# Copy MongoDB CA certificate
cp /path/to/mongodb-ca.crt /etc/es-chat/certs/

# Set permissions
chmod 600 /etc/es-chat/certs/*
```

### 2. Create Production Environment File

```bash
# Create .env.production
cat > /home/ubuntu/es-chat-app/.env.production << EOF
# Environment
APP_ENV=production
LOG_LEVEL=WARNING

# Elasticsearch
ELASTICSEARCH_HOST=https://elasticsearch.internal:9200
ELASTICSEARCH_USERNAME=elastic
ELASTICSEARCH_PASSWORD=your-secure-password
ELASTICSEARCH_CA_CERT=/etc/es-chat/certs/elasticsearch-ca.crt
ELASTICSEARCH_VERIFY_SSL=true

# MongoDB
MONGODB_URI=mongodb+srv://user:password@mongodb.internal:27017/es_chat?ssl=true&retryWrites=true
MONGODB_CA_CERT=/etc/es-chat/certs/mongodb-ca.crt

# Azure OpenAI
AZURE_OPENAI_API_KEY=your-api-key
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4

# Azure Entra AD
AZURE_AD_TENANT_ID=your-tenant-id
AZURE_AD_CLIENT_ID=your-client-id
AZURE_AD_CLIENT_SECRET=your-client-secret

# Application
BACKEND_URL=https://api.example.com
FRONTEND_URL=https://example.com
CORS_ORIGINS=https://example.com

# Security
JWT_SECRET=your-very-secure-random-secret-here
EOF
```

### 3. Update docker-compose.yml for Production

Create `docker-compose.prod.yml`:

```yaml
version: '3.8'

services:
  backend:
    image: es-chat-backend:latest
    restart: always
    ports:
      - "8000:8000"
    environment:
      - APP_ENV=production
      - LOG_LEVEL=WARNING
    env_file:
      - .env.production
    volumes:
      - /etc/es-chat/certs:/etc/es-chat/certs:ro
      - backend_logs:/var/log/es-chat
    networks:
      - es-chat-network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  frontend:
    image: es-chat-frontend:latest
    restart: always
    ports:
      - "5173:5173"
    environment:
      - VITE_API_URL=https://api.example.com
    networks:
      - es-chat-network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:5173/"]
      interval: 30s
      timeout: 10s
      retries: 3

  nginx:
    image: nginx:alpine
    restart: always
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - /etc/letsencrypt:/etc/letsencrypt:ro
      - nginx_cache:/var/cache/nginx
    depends_on:
      - backend
      - frontend
    networks:
      - es-chat-network

networks:
  es-chat-network:
    driver: bridge

volumes:
  backend_logs:
  nginx_cache:
```

### 4. Configure Nginx Reverse Proxy

Create `nginx.conf`:

```nginx
upstream backend {
    server backend:8000;
}

upstream frontend {
    server frontend:5173;
}

server {
    listen 80;
    server_name example.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name example.com;

    ssl_certificate /etc/letsencrypt/live/example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/example.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    # API routes
    location /api/ {
        proxy_pass http://backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 60s;
    }

    # Frontend
    location / {
        proxy_pass http://frontend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # Cache static assets
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        proxy_pass http://frontend;
        proxy_cache_valid 200 1d;
        expires 1d;
    }
}
```

## Deployment Steps

### 1. Build Docker Images

```bash
cd /home/ubuntu/es-chat-app

# Build backend
docker build -t es-chat-backend:latest ./backend

# Build frontend
docker build -t es-chat-frontend:latest ./frontend
```

### 2. Start Services

```bash
# Using production docker-compose
docker-compose -f docker-compose.prod.yml up -d

# Check status
docker-compose -f docker-compose.prod.yml ps

# View logs
docker-compose -f docker-compose.prod.yml logs -f backend
```

### 3. Verify Deployment

```bash
# Check backend health
curl https://api.example.com/health

# Check frontend
curl https://example.com

# Check database connection
docker-compose -f docker-compose.prod.yml exec backend python -c "from app.database.mongodb import db_client; print('MongoDB connected')"

# Check Elasticsearch connection
docker-compose -f docker-compose.prod.yml exec backend python -c "from app.elasticsearch.client import es_client; print('Elasticsearch connected')"
```

## Monitoring & Logging

### 1. Set Up Logging

```bash
# Create log directory
mkdir -p /var/log/es-chat

# Configure log rotation
cat > /etc/logrotate.d/es-chat << EOF
/var/log/es-chat/*.log {
    daily
    rotate 14
    compress
    delaycompress
    notifempty
    create 0640 appuser appuser
    sharedscripts
}
EOF
```

### 2. Monitor Services

```bash
# Check service health
docker-compose -f docker-compose.prod.yml ps

# View resource usage
docker stats

# Check logs for errors
docker-compose -f docker-compose.prod.yml logs --tail=100 backend
```

### 3. Set Up Alerts

Configure monitoring tools (Prometheus, Grafana, ELK) to alert on:
- Backend service down
- High error rate
- Slow query execution
- MongoDB connection issues
- Elasticsearch connection issues

## Scaling Considerations

### Horizontal Scaling

For multiple backend instances:

```yaml
backend:
  deploy:
    replicas: 3
  # ... rest of config
```

### Load Balancing

Use Nginx or cloud load balancer to distribute traffic across instances.

### Database Scaling

- MongoDB: Use replica sets for high availability
- Elasticsearch: Use multiple nodes with proper sharding

## Backup & Recovery

### 1. MongoDB Backup

```bash
# Daily backup
0 2 * * * mongodump --uri="mongodb+srv://user:pass@mongo.internal/es_chat" --out=/backups/mongodb/$(date +\%Y\%m\%d)
```

### 2. Elasticsearch Snapshot

```bash
# Configure snapshot repository
curl -X PUT "https://elasticsearch:9200/_snapshot/backup" \
  -H 'Content-Type: application/json' \
  -d '{
    "type": "fs",
    "settings": {
      "location": "/mnt/backups/elasticsearch"
    }
  }'

# Create daily snapshot
0 3 * * * curl -X PUT "https://elasticsearch:9200/_snapshot/backup/snapshot-$(date +\%Y\%m\%d)"
```

### 3. Restore Procedure

```bash
# Restore MongoDB
mongorestore --uri="mongodb+srv://user:pass@mongo.internal/es_chat" /backups/mongodb/20240101

# Restore Elasticsearch
curl -X POST "https://elasticsearch:9200/_snapshot/backup/snapshot-20240101/_restore"
```

## Security Hardening

### 1. Firewall Rules

```bash
# Allow only necessary ports
ufw allow 22/tcp      # SSH
ufw allow 443/tcp     # HTTPS
ufw allow 80/tcp      # HTTP redirect
ufw default deny incoming
ufw default allow outgoing
```

### 2. SSL/TLS Configuration

- Use TLS 1.2+ only
- Enable HSTS headers
- Implement certificate pinning
- Regular certificate rotation

### 3. Access Control

- Implement IP whitelisting
- Use VPN for internal access
- Enable MFA for admin accounts
- Regular security audits

## Troubleshooting

### Backend Won't Start

```bash
# Check logs
docker-compose -f docker-compose.prod.yml logs backend

# Verify environment variables
docker-compose -f docker-compose.prod.yml config | grep -A 20 "backend:"

# Test Elasticsearch connection
docker-compose -f docker-compose.prod.yml exec backend python -c "
from app.elasticsearch.client import es_client
import asyncio
asyncio.run(es_client.list_indices())
"
```

### High Latency

```bash
# Check query execution time
docker-compose -f docker-compose.prod.yml logs backend | grep "execution_time"

# Monitor resource usage
docker stats

# Check Elasticsearch performance
curl -X GET "https://elasticsearch:9200/_nodes/stats"
```

### Database Connection Issues

```bash
# Test MongoDB connection
docker-compose -f docker-compose.prod.yml exec backend python -c "
from pymongo import MongoClient
client = MongoClient('mongodb://user:pass@mongodb:27017')
print('Connected:', client.admin.command('ping'))
"

# Check MongoDB logs
docker-compose -f docker-compose.prod.yml logs mongodb
```

## Maintenance

### Regular Tasks

- [ ] Monitor disk space
- [ ] Review and rotate logs
- [ ] Update dependencies
- [ ] Test backup/restore procedures
- [ ] Review audit logs
- [ ] Update SSL certificates (30 days before expiry)
- [ ] Security patches

### Update Procedure

```bash
# Pull latest code
git pull origin main

# Rebuild images
docker build -t es-chat-backend:latest ./backend
docker build -t es-chat-frontend:latest ./frontend

# Restart services
docker-compose -f docker-compose.prod.yml down
docker-compose -f docker-compose.prod.yml up -d

# Verify
docker-compose -f docker-compose.prod.yml ps
```

## Support

For issues or questions:
1. Check logs: `docker-compose -f docker-compose.prod.yml logs`
2. Review troubleshooting section above
3. Check documentation
4. Contact support team
