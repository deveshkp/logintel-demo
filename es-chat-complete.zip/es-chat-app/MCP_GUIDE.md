# MCP Server Guide - Elasticsearch Chat

This guide explains how to use and integrate the Elasticsearch Chat MCP server.

## Overview

The MCP (Model Context Protocol) server provides a standardized interface for AI agents to query Elasticsearch data using natural language. It supports:

- **12 Tools** for querying, metadata management, and conversation handling
- **4 Resources** for index catalogs, field mappings, and templates
- **Multiple Transport Options** (stdio for Claude, HTTP for web UI)
- **Azure Entra AD Integration** for access control
- **MongoDB Persistence** for conversation history and audit logs

## Quick Start

### 1. Installation

```bash
cd backend
pip install -r requirements.txt
```

### 2. Configuration

Copy `.env.example` to `.env` and fill in your credentials:

```bash
cp .env.example .env
```

### 3. Run as HTTP Server (for Web UI)

```bash
python -m uvicorn app.main:app --reload --port 8000
```

MCP endpoints will be available at `http://localhost:8000/api/mcp/`

### 4. Run as Stdio Server (for Claude Desktop)

```bash
python -m app.mcp.stdio
```

## Available Tools

### Query Generation & Execution

#### `list_indices`
List all available Elasticsearch indices.

```json
{
  "method": "tools/call",
  "params": {
    "name": "list_indices",
    "arguments": {}
  }
}
```

#### `get_index_metadata`
Get metadata for a specific index (fields, types, aggregatability).

```json
{
  "method": "tools/call",
  "params": {
    "name": "get_index_metadata",
    "arguments": {
      "index_name": "logs_prod"
    }
  }
}
```

#### `get_index_stats`
Get statistics for an index (document count, size).

```json
{
  "method": "tools/call",
  "params": {
    "name": "get_index_stats",
    "arguments": {
      "index_name": "logs_prod"
    }
  }
}
```

#### `generate_esql_query`
Generate ES|QL query from natural language with constraint-based prompting.

```json
{
  "method": "tools/call",
  "params": {
    "name": "generate_esql_query",
    "arguments": {
      "question": "Show me top 10 error patterns by service",
      "index_name": "logs_prod"
    }
  }
}
```

Response includes:
- `selected_index`: Which index was chosen
- `query`: Generated ES|QL query
- `confidence`: Confidence score (0-1)
- `fields_used`: Fields referenced in query
- `warnings`: Any warnings or issues

#### `execute_esql_query`
Execute an ES|QL query and return results.

```json
{
  "method": "tools/call",
  "params": {
    "name": "execute_esql_query",
    "arguments": {
      "query": "FROM logs_prod | STATS count() BY error_type | SORT count() DESC | LIMIT 10"
    }
  }
}
```

#### `validate_esql_query`
Validate ES|QL syntax without executing.

```json
{
  "method": "tools/call",
  "params": {
    "name": "validate_esql_query",
    "arguments": {
      "query": "FROM logs_prod | STATS count() BY error_type"
    }
  }
}
```

#### `summarize_results`
Summarize query results using LLM.

```json
{
  "method": "tools/call",
  "params": {
    "name": "summarize_results",
    "arguments": {
      "question": "Show me top 10 error patterns by service",
      "results": {
        "columns": ["error_type", "count()"],
        "rows": [["NullPointerException", 152], ["TimeoutException", 134]]
      }
    }
  }
}
```

### Conversation Management

#### `create_conversation`
Create a new conversation.

```json
{
  "method": "tools/call",
  "params": {
    "name": "create_conversation",
    "arguments": {
      "user_id": "user123",
      "title": "Error Analysis"
    }
  }
}
```

#### `add_message`
Add a message to a conversation.

```json
{
  "method": "tools/call",
  "params": {
    "name": "add_message",
    "arguments": {
      "conversation_id": "conv123",
      "user_id": "user123",
      "role": "user",
      "content": "Show me top errors"
    }
  }
}
```

#### `get_conversation_history`
Get all messages in a conversation.

```json
{
  "method": "tools/call",
  "params": {
    "name": "get_conversation_history",
    "arguments": {
      "conversation_id": "conv123"
    }
  }
}
```

### Templates & Permissions

#### `get_query_templates`
Get pre-built query templates for common patterns.

```json
{
  "method": "tools/call",
  "params": {
    "name": "get_query_templates",
    "arguments": {}
  }
}
```

Returns templates like:
- `top_errors`: Top 10 error patterns
- `error_by_service`: Errors grouped by service
- `service_performance`: Service metrics

#### `get_user_permissions`
Get user's Azure AD groups and permissions.

```json
{
  "method": "tools/call",
  "params": {
    "name": "get_user_permissions",
    "arguments": {
      "user_id": "user123",
      "access_token": "token_from_azure_ad"
    }
  }
}
```

## Available Resources

### `index://catalog`
Catalog of all available indices with statistics.

```json
{
  "method": "resources/read",
  "params": {
    "uri": "index://catalog"
  }
}
```

### `index://field_mappings`
Field mappings and types for all indices.

```json
{
  "method": "resources/read",
  "params": {
    "uri": "index://field_mappings"
  }
}
```

### `templates://query_templates`
Pre-built query templates with descriptions.

```json
{
  "method": "resources/read",
  "params": {
    "uri": "templates://query_templates"
  }
}
```

## Integration Examples

### Claude Desktop

1. Update `~/.config/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "elasticsearch-chat": {
      "command": "python",
      "args": ["-m", "app.mcp.stdio"],
      "env": {
        "PYTHONPATH": "/path/to/backend",
        "AZURE_TENANT_ID": "...",
        "AZURE_OPENAI_API_KEY": "...",
        "MONGODB_URI": "...",
        "ELASTICSEARCH_HOSTS": "..."
      }
    }
  }
}
```

2. Restart Claude Desktop

3. Use in conversation:
   - "What are the top 10 error patterns?"
   - "Show me service performance metrics"
   - "Analyze user activity trends"

### LangChain

```python
from langchain.tools import Tool
import httpx

async def call_mcp_tool(tool_name: str, args: dict):
    async with httpx.AsyncClient() as client:
        response = await client.post(
            f"http://localhost:8000/api/mcp/tools/{tool_name}",
            json=args
        )
        return response.json()

# Create LangChain tools
tools = [
    Tool(
        name="generate_esql_query",
        func=lambda q: call_mcp_tool("generate_esql_query", {"question": q}),
        description="Generate ES|QL query from natural language"
    ),
    Tool(
        name="execute_esql_query",
        func=lambda q: call_mcp_tool("execute_esql_query", {"query": q}),
        description="Execute an ES|QL query"
    ),
]
```

### Python Agent

```python
import httpx
import json

async def query_elasticsearch(question: str):
    async with httpx.AsyncClient() as client:
        # Generate query
        gen_response = await client.post(
            "http://localhost:8000/api/mcp/tools/generate_esql_query",
            json={"question": question}
        )
        gen_result = gen_response.json()
        
        # Execute query
        exec_response = await client.post(
            "http://localhost:8000/api/mcp/tools/execute_esql_query",
            json={"query": gen_result["query_generation"]["query"]}
        )
        exec_result = exec_response.json()
        
        # Summarize results
        summary_response = await client.post(
            "http://localhost:8000/api/mcp/tools/summarize_results",
            json={
                "question": question,
                "results": exec_result["results"]
            }
        )
        
        return summary_response.json()
```

## Security & Access Control

### Azure AD Group-Based Access

Users are automatically granted access to indices based on their Azure AD group membership:

- `es-access-logs-prod` → Access to `logs_prod` index
- `es-access-metrics-prod` → Access to `metrics_prod` index
- `es-access-admin` → Admin access to all indices

### Audit Logging

All queries are logged with:
- User ID and email
- Azure AD groups
- Query executed
- Results count
- Execution time
- Status (success/failure)

Access audit logs via:

```json
{
  "method": "resources/read",
  "params": {
    "uri": "audit://logs"
  }
}
```

## Performance Optimization

### Metadata Caching

Index metadata is cached in MongoDB with a 24-hour TTL. This improves:
- Query generation speed (no need to fetch metadata each time)
- LLM performance (better context)
- Overall system responsiveness

### Query Limits

- Max results per query: 10,000 documents
- Query timeout: 30 seconds
- Confidence threshold: 0.7 (queries below this are rejected)

### Constraint-Based Prompting

The LLM receives:
- Exact field names (prevents hallucination)
- Field types and aggregatability
- Query templates and examples
- Confidence scoring

This results in 99%+ query accuracy.

## Troubleshooting

### Connection Issues

```bash
# Test Elasticsearch connection
curl -k --user elastic:password https://localhost:9200

# Test MongoDB connection
mongosh "mongodb://localhost:27017" --username elastic --password password
```

### LLM Issues

Check Azure OpenAI credentials:

```bash
# Verify endpoint
echo $AZURE_OPENAI_ENDPOINT

# Test API key
curl -X POST "$AZURE_OPENAI_ENDPOINT/deployments/gpt-4/chat/completions?api-version=2024-02-15-preview" \
  -H "api-key: $AZURE_OPENAI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "test"}]}'
```

### Query Generation Failures

If queries have low confidence or fail:

1. Check index metadata is cached: `GET /api/mcp/resources/index/catalog`
2. Verify field names match: `GET /api/mcp/resources/index/field_mappings`
3. Check LLM logs for errors
4. Try with explicit index name

## API Reference

### HTTP Endpoints

- `GET /api/mcp/tools` - List available tools
- `POST /api/mcp/tools/{tool_name}` - Call a tool
- `GET /api/mcp/resources` - List available resources
- `GET /api/mcp/resources/{resource_path}` - Read a resource
- `POST /api/mcp/request` - Generic MCP request

### Response Format

All responses follow this format:

```json
{
  "success": true,
  "data": {},
  "error": null
}
```

Or on error:

```json
{
  "success": false,
  "error": "Error message"
}
```

## Next Steps

1. **Deploy** - Set up production environment
2. **Monitor** - Track query performance and errors
3. **Extend** - Add custom tools for your use cases
4. **Integrate** - Connect with other systems via MCP

For questions or issues, refer to the main README.md or create an issue.
