"""Configuration management for the Elasticsearch Chat application."""

from pydantic_settings import BaseSettings
from typing import List
import os


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # FastAPI Configuration
    environment: str = "development"
    debug: bool = True
    api_port: int = 8000
    api_host: str = "0.0.0.0"
    cors_origins: List[str] = ["http://localhost:3000", "http://localhost:5173"]

    # Azure Entra AD
    azure_tenant_id: str
    azure_client_id: str
    azure_client_secret: str
    azure_redirect_uri: str = "http://localhost:8000/api/auth/callback"

    # Azure OpenAI
    azure_openai_api_key: str
    azure_openai_endpoint: str
    azure_openai_deployment_name: str = "gpt-4"

    # MongoDB (On-Premises)
    mongodb_uri: str
    mongodb_db_name: str = "es_chat"
    mongodb_ssl_cert_path: str = ""

    # Elasticsearch (On-Premises)
    elasticsearch_hosts: str  # Can be comma-separated for multiple hosts
    elasticsearch_username: str
    elasticsearch_password: str
    elasticsearch_ssl_cert_path: str = ""
    elasticsearch_ssl_verify: bool = True

    # Metadata Caching
    metadata_cache_ttl_hours: int = 24
    metadata_refresh_interval_hours: int = 24

    # Query Configuration
    query_timeout_seconds: int = 30
    query_max_results: int = 10000
    query_confidence_threshold: float = 0.7

    # Logging
    log_level: str = "INFO"
    log_format: str = "json"

    # Security
    secret_key: str
    session_timeout_minutes: int = 60

    class Config:
        env_file = ".env"
        case_sensitive = False

    @property
    def elasticsearch_hosts_list(self) -> List[str]:
        """Parse comma-separated Elasticsearch hosts."""
        return [host.strip() for host in self.elasticsearch_hosts.split(",")]

    @property
    def is_production(self) -> bool:
        """Check if running in production."""
        return self.environment == "production"

    @property
    def is_development(self) -> bool:
        """Check if running in development."""
        return self.environment == "development"


# Load settings from environment
settings = Settings()
