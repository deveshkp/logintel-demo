"""MongoDB connection and utilities."""

import logging
from typing import Optional
from motor.motor_asyncio import AsyncClient, AsyncDatabase
from pymongo.errors import ConnectionFailure
from app.config import settings

logger = logging.getLogger(__name__)

# Global MongoDB client and database
_db_client: Optional[AsyncClient] = None
_database: Optional[AsyncDatabase] = None


async def connect_to_mongo() -> AsyncDatabase:
    """
    Connect to MongoDB.

    Returns:
        AsyncDatabase instance

    Raises:
        ConnectionFailure: If connection fails
    """
    global _db_client, _database

    try:
        # Build SSL options if certificate path is provided
        ssl_options = {}
        if settings.mongodb_ssl_cert_path:
            ssl_options = {
                "ssl": True,
                "ssl_certfile": settings.mongodb_ssl_cert_path,
                "ssl_cert_reqs": "CERT_REQUIRED",
            }

        _db_client = AsyncClient(
            settings.mongodb_uri,
            **ssl_options,
        )

        # Test connection
        await _db_client.admin.command("ping")
        logger.info("Successfully connected to MongoDB")

        _database = _db_client[settings.mongodb_db_name]
        return _database

    except ConnectionFailure as e:
        logger.error(f"Failed to connect to MongoDB: {str(e)}")
        raise
    except Exception as e:
        logger.error(f"Unexpected error connecting to MongoDB: {str(e)}")
        raise


async def close_mongo_connection():
    """Close MongoDB connection."""
    global _db_client

    if _db_client:
        _db_client.close()
        logger.info("Closed MongoDB connection")


async def get_database() -> AsyncDatabase:
    """
    Get MongoDB database instance.

    Returns:
        AsyncDatabase instance
    """
    global _database

    if _database is None:
        _database = await connect_to_mongo()

    return _database


async def create_indexes():
    """Create necessary MongoDB indexes."""
    try:
        db = await get_database()

        # Conversations collection indexes
        await db.conversations.create_index("user_id")
        await db.conversations.create_index("created_at")
        await db.conversations.create_index([("user_id", 1), ("created_at", -1)])

        # Messages collection indexes
        await db.messages.create_index("conversation_id")
        await db.messages.create_index("created_at")
        await db.messages.create_index([("conversation_id", 1), ("created_at", 1)])

        # Query logs indexes
        await db.query_logs.create_index("user_id")
        await db.query_logs.create_index("conversation_id")
        await db.query_logs.create_index("created_at")
        await db.query_logs.create_index([("user_id", 1), ("created_at", -1)])

        # Debug logs indexes
        await db.debug_logs.create_index("conversation_id")
        await db.debug_logs.create_index("message_id")
        await db.debug_logs.create_index("created_at")

        # Audit logs indexes (immutable)
        await db.audit_logs.create_index("user_id")
        await db.audit_logs.create_index("action")
        await db.audit_logs.create_index("created_at")
        await db.audit_logs.create_index([("user_id", 1), ("created_at", -1)])

        # Metadata cache indexes
        await db.metadata_cache.create_index("index_name", unique=True)
        await db.metadata_cache.create_index("last_updated")

        logger.info("Successfully created MongoDB indexes")

    except Exception as e:
        logger.error(f"Error creating indexes: {str(e)}")
        raise
