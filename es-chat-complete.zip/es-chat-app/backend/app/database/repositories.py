"""Database repositories for data access."""

import logging
from typing import List, Optional, Dict, Any
from datetime import datetime
from bson import ObjectId
from motor.motor_asyncio import AsyncDatabase
from app.database.models import (
    Conversation,
    Message,
    QueryLog,
    DebugLog,
    AuditLog,
    MetadataCache,
)

logger = logging.getLogger(__name__)


class ConversationRepository:
    """Repository for conversation operations."""

    def __init__(self, db: AsyncDatabase):
        self.collection = db.conversations

    async def create(self, user_id: str, title: str, description: Optional[str] = None) -> str:
        """Create a new conversation."""
        doc = {
            "user_id": user_id,
            "title": title,
            "description": description,
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "is_pinned": False,
        }
        result = await self.collection.insert_one(doc)
        return str(result.inserted_id)

    async def get_by_id(self, conversation_id: str) -> Optional[Conversation]:
        """Get conversation by ID."""
        doc = await self.collection.find_one({"_id": ObjectId(conversation_id)})
        return Conversation(**doc) if doc else None

    async def list_by_user(self, user_id: str, limit: int = 50) -> List[Conversation]:
        """List conversations for a user."""
        docs = await self.collection.find({"user_id": user_id}).sort("created_at", -1).limit(limit).to_list(None)
        return [Conversation(**doc) for doc in docs]

    async def update_title(self, conversation_id: str, title: str) -> bool:
        """Update conversation title."""
        result = await self.collection.update_one(
            {"_id": ObjectId(conversation_id)},
            {"$set": {"title": title, "updated_at": datetime.utcnow()}},
        )
        return result.modified_count > 0

    async def toggle_pin(self, conversation_id: str) -> bool:
        """Toggle conversation pin status."""
        conv = await self.get_by_id(conversation_id)
        if not conv:
            return False

        result = await self.collection.update_one(
            {"_id": ObjectId(conversation_id)},
            {"$set": {"is_pinned": not conv.is_pinned, "updated_at": datetime.utcnow()}},
        )
        return result.modified_count > 0

    async def delete(self, conversation_id: str) -> bool:
        """Delete a conversation."""
        result = await self.collection.delete_one({"_id": ObjectId(conversation_id)})
        return result.deleted_count > 0


class MessageRepository:
    """Repository for message operations."""

    def __init__(self, db: AsyncDatabase):
        self.collection = db.messages

    async def create(
        self, conversation_id: str, user_id: str, role: str, content: str
    ) -> str:
        """Create a new message."""
        doc = {
            "conversation_id": conversation_id,
            "user_id": user_id,
            "role": role,
            "content": content,
            "created_at": datetime.utcnow(),
        }
        result = await self.collection.insert_one(doc)
        return str(result.inserted_id)

    async def get_by_id(self, message_id: str) -> Optional[Message]:
        """Get message by ID."""
        doc = await self.collection.find_one({"_id": ObjectId(message_id)})
        return Message(**doc) if doc else None

    async def list_by_conversation(
        self, conversation_id: str, limit: int = 100
    ) -> List[Message]:
        """List messages in a conversation."""
        docs = (
            await self.collection.find({"conversation_id": conversation_id})
            .sort("created_at", 1)
            .limit(limit)
            .to_list(None)
        )
        return [Message(**doc) for doc in docs]


class QueryLogRepository:
    """Repository for query log operations."""

    def __init__(self, db: AsyncDatabase):
        self.collection = db.query_logs

    async def create(
        self,
        conversation_id: str,
        message_id: str,
        user_id: str,
        user_groups: List[str],
        question: str,
        selected_index: str,
        generated_query: str,
        query_confidence: float,
        execution_time_ms: float,
        result_count: int,
        status: str,
        error_message: Optional[str] = None,
    ) -> str:
        """Create a query log entry."""
        doc = {
            "conversation_id": conversation_id,
            "message_id": message_id,
            "user_id": user_id,
            "user_groups": user_groups,
            "question": question,
            "selected_index": selected_index,
            "generated_query": generated_query,
            "query_confidence": query_confidence,
            "execution_time_ms": execution_time_ms,
            "result_count": result_count,
            "status": status,
            "error_message": error_message,
            "created_at": datetime.utcnow(),
        }
        result = await self.collection.insert_one(doc)
        return str(result.inserted_id)

    async def list_by_user(self, user_id: str, limit: int = 100) -> List[QueryLog]:
        """List query logs for a user."""
        docs = (
            await self.collection.find({"user_id": user_id})
            .sort("created_at", -1)
            .limit(limit)
            .to_list(None)
        )
        return [QueryLog(**doc) for doc in docs]


class DebugLogRepository:
    """Repository for debug log operations."""

    def __init__(self, db: AsyncDatabase):
        self.collection = db.debug_logs

    async def create(
        self,
        conversation_id: str,
        message_id: str,
        log_type: str,
        llm_prompt: str,
        llm_response: str,
        tokens_used: int,
        execution_time_ms: float,
    ) -> str:
        """Create a debug log entry."""
        doc = {
            "conversation_id": conversation_id,
            "message_id": message_id,
            "log_type": log_type,
            "llm_prompt": llm_prompt,
            "llm_response": llm_response,
            "tokens_used": tokens_used,
            "execution_time_ms": execution_time_ms,
            "created_at": datetime.utcnow(),
        }
        result = await self.collection.insert_one(doc)
        return str(result.inserted_id)

    async def list_by_conversation(self, conversation_id: str) -> List[DebugLog]:
        """List debug logs for a conversation."""
        docs = (
            await self.collection.find({"conversation_id": conversation_id})
            .sort("created_at", 1)
            .to_list(None)
        )
        return [DebugLog(**doc) for doc in docs]


class AuditLogRepository:
    """Repository for audit log operations (immutable)."""

    def __init__(self, db: AsyncDatabase):
        self.collection = db.audit_logs

    async def create(
        self,
        user_id: str,
        user_email: str,
        user_groups: List[str],
        action: str,
        resource_type: str,
        resource_id: str,
        details: Dict[str, Any],
        status: str,
    ) -> str:
        """Create an audit log entry."""
        doc = {
            "user_id": user_id,
            "user_email": user_email,
            "user_groups": user_groups,
            "action": action,
            "resource_type": resource_type,
            "resource_id": resource_id,
            "details": details,
            "status": status,
            "created_at": datetime.utcnow(),
        }
        result = await self.collection.insert_one(doc)
        return str(result.inserted_id)

    async def list_by_user(self, user_id: str, limit: int = 100) -> List[AuditLog]:
        """List audit logs for a user."""
        docs = (
            await self.collection.find({"user_id": user_id})
            .sort("created_at", -1)
            .limit(limit)
            .to_list(None)
        )
        return [AuditLog(**doc) for doc in docs]


class MetadataCacheRepository:
    """Repository for metadata cache operations."""

    def __init__(self, db: AsyncDatabase):
        self.collection = db.metadata_cache

    async def upsert(
        self, index_name: str, fields: Dict[str, Any], settings: Dict[str, Any]
    ) -> str:
        """Create or update metadata cache."""
        doc = {
            "index_name": index_name,
            "fields": fields,
            "settings": settings,
            "last_updated": datetime.utcnow(),
            "ttl_hours": 24,
        }
        result = await self.collection.update_one(
            {"index_name": index_name},
            {"$set": doc},
            upsert=True,
        )
        return str(result.upserted_id or index_name)

    async def get(self, index_name: str) -> Optional[MetadataCache]:
        """Get cached metadata for an index."""
        doc = await self.collection.find_one({"index_name": index_name})
        return MetadataCache(**doc) if doc else None

    async def is_expired(self, index_name: str) -> bool:
        """Check if metadata cache is expired."""
        doc = await self.collection.find_one({"index_name": index_name})
        if not doc:
            return True

        age_hours = (datetime.utcnow() - doc["last_updated"]).total_seconds() / 3600
        return age_hours > doc.get("ttl_hours", 24)
