"""Pydantic models for database documents."""

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime
from enum import Enum


class UserRole(str, Enum):
    """User roles."""

    ADMIN = "admin"
    USER = "user"


class User(BaseModel):
    """User model."""

    id: str = Field(alias="_id")
    email: str
    name: str
    groups: List[str] = []
    role: UserRole = UserRole.USER
    created_at: datetime
    last_login: datetime

    class Config:
        populate_by_name = True


class Conversation(BaseModel):
    """Conversation model."""

    id: str = Field(alias="_id")
    user_id: str
    title: str
    description: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    is_pinned: bool = False

    class Config:
        populate_by_name = True


class Message(BaseModel):
    """Message model."""

    id: str = Field(alias="_id")
    conversation_id: str
    user_id: str
    role: str  # "user" or "assistant"
    content: str
    created_at: datetime

    class Config:
        populate_by_name = True


class QueryLog(BaseModel):
    """Query execution log model."""

    id: str = Field(alias="_id")
    conversation_id: str
    message_id: str
    user_id: str
    user_groups: List[str] = []
    question: str
    selected_index: str
    generated_query: str
    query_confidence: float
    execution_time_ms: float
    result_count: int
    status: str  # "success" or "error"
    error_message: Optional[str] = None
    created_at: datetime

    class Config:
        populate_by_name = True


class DebugLog(BaseModel):
    """Debug log for LLM interactions."""

    id: str = Field(alias="_id")
    conversation_id: str
    message_id: str
    log_type: str  # "query_generation", "summarization"
    llm_prompt: str
    llm_response: str
    tokens_used: int
    execution_time_ms: float
    created_at: datetime

    class Config:
        populate_by_name = True


class AuditLog(BaseModel):
    """Immutable audit log for compliance."""

    id: str = Field(alias="_id")
    user_id: str
    user_email: str
    user_groups: List[str] = []
    action: str  # "query_executed", "conversation_created", etc.
    resource_type: str  # "query", "conversation", etc.
    resource_id: str
    details: Dict[str, Any] = {}
    status: str  # "success" or "failure"
    created_at: datetime

    class Config:
        populate_by_name = True


class MetadataCache(BaseModel):
    """Cached index metadata."""

    id: str = Field(alias="_id")
    index_name: str
    fields: Dict[str, Any]  # Field name -> field info
    settings: Dict[str, Any]
    last_updated: datetime
    ttl_hours: int = 24

    class Config:
        populate_by_name = True


# Request/Response Models


class ChatMessageRequest(BaseModel):
    """Chat message request."""

    conversation_id: str
    content: str


class ChatMessageResponse(BaseModel):
    """Chat message response."""

    message_id: str
    conversation_id: str
    role: str
    content: str
    created_at: datetime


class QueryGenerationRequest(BaseModel):
    """Query generation request."""

    question: str
    conversation_id: str


class QueryGenerationResponse(BaseModel):
    """Query generation response."""

    selected_index: str
    query: str
    confidence: float
    reasoning: str
    fields_used: List[str]
    warnings: List[str] = []


class QueryExecutionResponse(BaseModel):
    """Query execution response."""

    query: str
    index: str
    execution_time_ms: float
    result_count: int
    results: Dict[str, Any]
    summary: str


class ConversationCreateRequest(BaseModel):
    """Create conversation request."""

    title: str
    description: Optional[str] = None


class ConversationResponse(BaseModel):
    """Conversation response."""

    id: str
    title: str
    description: Optional[str]
    created_at: datetime
    updated_at: datetime
    is_pinned: bool
    message_count: int = 0


class DebugLogResponse(BaseModel):
    """Debug log response."""

    id: str
    log_type: str
    llm_prompt: str
    llm_response: str
    tokens_used: int
    execution_time_ms: float
    created_at: datetime
