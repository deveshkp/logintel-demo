"""FastAPI application entry point."""

import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.database.mongodb import connect_to_mongo, close_mongo_connection, create_indexes
from app.utils.logger import setup_logging

# Setup logging
setup_logging(settings.log_level, settings.log_format)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application lifecycle."""
    # Startup
    logger.info("Starting Elasticsearch Chat application")
    try:
        await connect_to_mongo()
        await create_indexes()
        logger.info("Database initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize database: {str(e)}")
        raise

    yield

    # Shutdown
    logger.info("Shutting down application")
    await close_mongo_connection()


# Create FastAPI app
app = FastAPI(
    title="Elasticsearch Chat API",
    description="Natural language interface to Elasticsearch with Azure OpenAI",
    version="1.0.0",
    lifespan=lifespan,
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "environment": settings.environment,
        "debug": settings.debug,
    }


# Include MCP routes
from app.mcp.http import router as mcp_router

app.include_router(mcp_router)


# API routes
@app.get("/api/v1/status")
async def api_status():
    """API status endpoint."""
    return {
        "status": "ready",
        "version": "1.0.0",
    }


@app.get("/api/v1/mcp/info")
async def mcp_info():
    """MCP server information."""
    return {
        "name": "Elasticsearch Chat MCP Server",
        "version": "1.0.0",
        "description": "MCP server for natural language Elasticsearch queries",
        "capabilities": {
            "tools": True,
            "resources": True,
            "prompts": False,
        },
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        app,
        host=settings.api_host,
        port=settings.api_port,
        log_level=settings.log_level.lower(),
    )
