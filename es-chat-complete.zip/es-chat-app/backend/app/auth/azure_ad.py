"""Azure Entra AD (Azure AD) authentication integration."""

import logging
from typing import Optional, List
from msal import PublicClientApplication
from pydantic import BaseModel
from app.config import settings

logger = logging.getLogger(__name__)


class UserInfo(BaseModel):
    """User information from Azure AD."""

    id: str
    email: str
    name: str
    groups: List[str] = []


class AzureADClient:
    """Client for Azure Entra AD authentication."""

    def __init__(self):
        """Initialize Azure AD client."""
        self.app = PublicClientApplication(
            client_id=settings.azure_client_id,
            authority=f"https://login.microsoftonline.com/{settings.azure_tenant_id}",
        )
        self.scopes = ["https://graph.microsoft.com/.default"]

    def get_auth_url(self, state: str) -> str:
        """
        Generate Azure AD authorization URL.

        Args:
            state: State parameter for CSRF protection

        Returns:
            Authorization URL
        """
        auth_url = self.app.get_authorization_request_url(
            scopes=self.scopes,
            state=state,
            redirect_uri=settings.azure_redirect_uri,
        )
        return auth_url

    async def get_token_by_code(self, code: str) -> Optional[dict]:
        """
        Exchange authorization code for access token.

        Args:
            code: Authorization code from Azure AD

        Returns:
            Token response or None if failed
        """
        try:
            token_response = self.app.acquire_token_by_authorization_code(
                code=code,
                scopes=self.scopes,
                redirect_uri=settings.azure_redirect_uri,
            )

            if "access_token" in token_response:
                logger.info("Successfully acquired token from Azure AD")
                return token_response
            else:
                logger.error(f"Token acquisition failed: {token_response.get('error')}")
                return None
        except Exception as e:
            logger.error(f"Error acquiring token: {str(e)}")
            return None

    async def get_user_info(self, access_token: str) -> Optional[UserInfo]:
        """
        Get user information from Microsoft Graph API.

        Args:
            access_token: Access token from Azure AD

        Returns:
            User information or None if failed
        """
        try:
            import httpx

            headers = {"Authorization": f"Bearer {access_token}"}

            async with httpx.AsyncClient() as client:
                # Get user profile
                user_response = await client.get(
                    "https://graph.microsoft.com/v1.0/me",
                    headers=headers,
                )
                user_data = user_response.json()

                # Get user groups
                groups_response = await client.get(
                    "https://graph.microsoft.com/v1.0/me/memberOf",
                    headers=headers,
                )
                groups_data = groups_response.json()

                groups = [
                    item.get("displayName")
                    for item in groups_data.get("value", [])
                    if item.get("@odata.type") == "#microsoft.graph.group"
                ]

                user_info = UserInfo(
                    id=user_data.get("id"),
                    email=user_data.get("mail") or user_data.get("userPrincipalName"),
                    name=user_data.get("displayName"),
                    groups=groups,
                )

                logger.info(f"Retrieved user info: {user_info.email}")
                return user_info

        except Exception as e:
            logger.error(f"Error getting user info: {str(e)}")
            return None

    async def validate_token(self, access_token: str) -> bool:
        """
        Validate access token by attempting to use it.

        Args:
            access_token: Access token to validate

        Returns:
            True if valid, False otherwise
        """
        try:
            user_info = await self.get_user_info(access_token)
            return user_info is not None
        except Exception:
            return False


# Global Azure AD client instance
azure_ad_client = AzureADClient()
