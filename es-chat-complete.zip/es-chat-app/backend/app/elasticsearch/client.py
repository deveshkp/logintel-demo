"""Elasticsearch client wrapper with SSL support."""

import logging
from typing import List, Dict, Any, Optional
from elasticsearch import Elasticsearch
from elasticsearch.exceptions import ConnectionError, NotFoundError
from app.config import settings

logger = logging.getLogger(__name__)


class ElasticsearchClient:
    """Wrapper around Elasticsearch client with SSL support."""

    def __init__(self):
        """Initialize Elasticsearch client with SSL configuration."""
        self.client: Optional[Elasticsearch] = None
        self._connect()

    def _connect(self):
        """Connect to Elasticsearch cluster with SSL."""
        try:
            ssl_options = {}

            # Configure SSL if certificate path is provided
            if settings.elasticsearch_ssl_cert_path:
                ssl_options = {
                    "verify_certs": settings.elasticsearch_ssl_verify,
                    "ca_certs": settings.elasticsearch_ssl_cert_path,
                }

            self.client = Elasticsearch(
                hosts=settings.elasticsearch_hosts_list,
                basic_auth=(settings.elasticsearch_username, settings.elasticsearch_password),
                **ssl_options,
            )

            # Test connection
            info = self.client.info()
            logger.info(f"Connected to Elasticsearch {info['version']['number']}")

        except ConnectionError as e:
            logger.error(f"Failed to connect to Elasticsearch: {str(e)}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error connecting to Elasticsearch: {str(e)}")
            raise

    async def get_indices(self) -> List[str]:
        """
        Get list of all indices.

        Returns:
            List of index names
        """
        try:
            indices = self.client.indices.get_alias(index="*")
            return list(indices.keys())
        except Exception as e:
            logger.error(f"Error getting indices: {str(e)}")
            return []

    async def get_index_metadata(self, index_name: str) -> Optional[Dict[str, Any]]:
        """
        Get index metadata including mappings and settings.

        Args:
            index_name: Name of the index

        Returns:
            Index metadata or None if not found
        """
        try:
            # Get mappings
            mappings = self.client.indices.get_mapping(index=index_name)

            # Get settings
            settings_response = self.client.indices.get_settings(index=index_name)

            # Get field capabilities
            field_caps = self.client.field_caps(index=index_name, fields="*")

            return {
                "index_name": index_name,
                "mappings": mappings.get(index_name, {}).get("mappings", {}),
                "settings": settings_response.get(index_name, {}).get("settings", {}),
                "field_capabilities": field_caps.get("fields", {}),
            }

        except NotFoundError:
            logger.warning(f"Index not found: {index_name}")
            return None
        except Exception as e:
            logger.error(f"Error getting index metadata for {index_name}: {str(e)}")
            return None

    async def get_index_stats(self, index_name: str) -> Optional[Dict[str, Any]]:
        """
        Get index statistics.

        Args:
            index_name: Name of the index

        Returns:
            Index statistics or None if not found
        """
        try:
            stats = self.client.indices.stats(index=index_name)
            count = self.client.count(index=index_name)

            return {
                "index_name": index_name,
                "doc_count": count.get("count", 0),
                "size_in_bytes": stats.get("indices", {})
                .get(index_name, {})
                .get("primaries", {})
                .get("store", {})
                .get("size_in_bytes", 0),
                "stats": stats,
            }

        except NotFoundError:
            logger.warning(f"Index not found: {index_name}")
            return None
        except Exception as e:
            logger.error(f"Error getting index stats for {index_name}: {str(e)}")
            return None

    async def execute_esql_query(
        self, query: str, timeout_seconds: int = 30
    ) -> Dict[str, Any]:
        """
        Execute ES|QL query.

        Args:
            query: ES|QL query string
            timeout_seconds: Query timeout in seconds

        Returns:
            Query results

        Raises:
            Exception: If query execution fails
        """
        try:
            result = self.client.esql.query(
                body={"query": query},
                request_timeout=timeout_seconds,
            )
            return result
        except Exception as e:
            logger.error(f"Error executing ES|QL query: {str(e)}")
            raise

    async def validate_esql_query(self, query: str) -> tuple[bool, Optional[str]]:
        """
        Validate ES|QL query syntax without executing it.

        Args:
            query: ES|QL query string

        Returns:
            Tuple of (is_valid, error_message)
        """
        try:
            # Try to parse the query
            # ES|QL validation is done by attempting a dry run
            # For now, we'll do basic syntax checks
            query_upper = query.upper().strip()

            # Check if query starts with FROM
            if not query_upper.startswith("FROM"):
                return False, "Query must start with FROM"

            # Check for basic syntax
            if "|" not in query:
                return False, "Query must contain pipe operators"

            return True, None

        except Exception as e:
            return False, str(e)

    def close(self):
        """Close Elasticsearch connection."""
        if self.client:
            self.client.close()
            logger.info("Closed Elasticsearch connection")


# Global Elasticsearch client instance
es_client = ElasticsearchClient()
