"""HTTP wrapper for MCP server for web UI integration."""

from fastapi import APIRouter, HTTPException
from typing import Dict, Any
import logging
from app.mcp.server import mcp_server

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/mcp", tags=["mcp"])


@router.get("/tools")
async def list_tools():
    """List available MCP tools."""
    try:
        return mcp_server._list_tools()
    except Exception as e:
        logger.error(f"Error listing tools: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/tools/{tool_name}")
async def call_tool(tool_name: str, args: Dict[str, Any]):
    """Call an MCP tool."""
    try:
        result = await mcp_server._call_tool(tool_name, args)
        return result
    except Exception as e:
        logger.error(f"Error calling tool {tool_name}: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/resources")
async def list_resources():
    """List available MCP resources."""
    try:
        return mcp_server._list_resources()
    except Exception as e:
        logger.error(f"Error listing resources: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/resources/{resource_path:path}")
async def read_resource(resource_path: str):
    """Read an MCP resource."""
    try:
        resource_uri = resource_path.replace("/", "://", 1)
        result = await mcp_server._read_resource(resource_uri)
        return result
    except Exception as e:
        logger.error(f"Error reading resource: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/request")
async def handle_request(request: Dict[str, Any]):
    """Handle generic MCP request."""
    try:
        result = await mcp_server.handle_request(request)
        return result
    except Exception as e:
        logger.error(f"Error handling MCP request: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
