"""MCP (Model Context Protocol) server implementation."""

import logging
import json
from typing import Any, Dict, List, Optional
from pydantic import BaseModel
import sys
import asyncio

logger = logging.getLogger(__name__)


class Tool(BaseModel):
    """MCP Tool definition."""

    name: str
    description: str
    inputSchema: Dict[str, Any]


class Resource(BaseModel):
    """MCP Resource definition."""

    uri: str
    name: str
    description: str
    mimeType: str = "application/json"


class MCPServer:
    """Model Context Protocol Server for Elasticsearch Chat."""

    def __init__(self):
        """Initialize MCP server."""
        self.tools: Dict[str, callable] = {}
        self.resources: Dict[str, callable] = {}
        self._register_tools()
        self._register_resources()

    def _register_tools(self):
        """Register all available tools."""
        self.tools = {
            "list_indices": self._list_indices,
            "get_index_metadata": self._get_index_metadata,
            "get_index_stats": self._get_index_stats,
            "generate_esql_query": self._generate_esql_query,
            "execute_esql_query": self._execute_esql_query,
            "validate_esql_query": self._validate_esql_query,
            "summarize_results": self._summarize_results,
            "create_conversation": self._create_conversation,
            "add_message": self._add_message,
            "get_conversation_history": self._get_conversation_history,
            "get_query_templates": self._get_query_templates,
            "get_user_permissions": self._get_user_permissions,
        }

    def _register_resources(self):
        """Register all available resources."""
        self.resources = {
            "index_catalog": self._get_index_catalog,
            "field_mappings": self._get_field_mappings,
            "query_templates": self._get_query_templates_resource,
            "audit_logs": self._get_audit_logs,
        }

    # ==================== TOOLS ====================

    async def _list_indices(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """List all available Elasticsearch indices."""
        from app.elasticsearch.client import es_client

        try:
            indices = await es_client.get_indices()
            return {
                "success": True,
                "indices": indices,
                "count": len(indices),
            }
        except Exception as e:
            logger.error(f"Error listing indices: {str(e)}")
            return {"success": False, "error": str(e)}

    async def _get_index_metadata(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Get metadata for a specific index."""
        from app.elasticsearch.client import es_client

        index_name = args.get("index_name")
        if not index_name:
            return {"success": False, "error": "index_name is required"}

        try:
            metadata = await es_client.get_index_metadata(index_name)
            if metadata:
                return {"success": True, "metadata": metadata}
            else:
                return {"success": False, "error": f"Index not found: {index_name}"}
        except Exception as e:
            logger.error(f"Error getting index metadata: {str(e)}")
            return {"success": False, "error": str(e)}

    async def _get_index_stats(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Get statistics for a specific index."""
        from app.elasticsearch.client import es_client

        index_name = args.get("index_name")
        if not index_name:
            return {"success": False, "error": "index_name is required"}

        try:
            stats = await es_client.get_index_stats(index_name)
            if stats:
                return {"success": True, "stats": stats}
            else:
                return {"success": False, "error": f"Index not found: {index_name}"}
        except Exception as e:
            logger.error(f"Error getting index stats: {str(e)}")
            return {"success": False, "error": str(e)}

    async def _generate_esql_query(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Generate ES|QL query from natural language."""
        from app.llm.azure_openai import llm_client
        from app.elasticsearch.client import es_client

        question = args.get("question")
        index_name = args.get("index_name")

        if not question:
            return {"success": False, "error": "question is required"}

        try:
            # Get available indices
            indices = await es_client.get_indices()

            # If specific index provided, use it; otherwise use all
            if index_name:
                indices = [index_name]

            # Get metadata for indices
            index_metadata = {}
            for idx in indices[:5]:  # Limit to first 5 for performance
                metadata = await es_client.get_index_metadata(idx)
                if metadata:
                    index_metadata[idx] = metadata

            # Generate query using LLM
            result = await llm_client.generate_esql_query(
                question, index_metadata, indices
            )

            return {"success": True, "query_generation": result}

        except Exception as e:
            logger.error(f"Error generating ES|QL query: {str(e)}")
            return {"success": False, "error": str(e)}

    async def _execute_esql_query(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Execute an ES|QL query."""
        from app.elasticsearch.client import es_client

        query = args.get("query")
        if not query:
            return {"success": False, "error": "query is required"}

        try:
            # Validate query first
            is_valid, error_msg = await es_client.validate_esql_query(query)
            if not is_valid:
                return {
                    "success": False,
                    "error": f"Invalid query: {error_msg}",
                }

            # Execute query
            result = await es_client.execute_esql_query(query)
            return {
                "success": True,
                "results": result,
                "row_count": len(result.get("rows", [])),
            }

        except Exception as e:
            logger.error(f"Error executing ES|QL query: {str(e)}")
            return {"success": False, "error": str(e)}

    async def _validate_esql_query(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Validate ES|QL query syntax."""
        from app.elasticsearch.client import es_client

        query = args.get("query")
        if not query:
            return {"success": False, "error": "query is required"}

        try:
            is_valid, error_msg = await es_client.validate_esql_query(query)
            return {
                "success": True,
                "is_valid": is_valid,
                "error": error_msg,
            }

        except Exception as e:
            logger.error(f"Error validating ES|QL query: {str(e)}")
            return {"success": False, "error": str(e)}

    async def _summarize_results(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Summarize query results using LLM."""
        from app.llm.azure_openai import llm_client

        question = args.get("question")
        results = args.get("results")

        if not question or not results:
            return {"success": False, "error": "question and results are required"}

        try:
            summary = await llm_client.summarize_results(question, results)
            return {"success": True, "summary": summary}

        except Exception as e:
            logger.error(f"Error summarizing results: {str(e)}")
            return {"success": False, "error": str(e)}

    async def _create_conversation(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new conversation."""
        from app.database.mongodb import get_database
        from app.database.repositories import ConversationRepository

        user_id = args.get("user_id")
        title = args.get("title")

        if not user_id or not title:
            return {"success": False, "error": "user_id and title are required"}

        try:
            db = await get_database()
            repo = ConversationRepository(db)
            conversation_id = await repo.create(user_id, title)

            return {
                "success": True,
                "conversation_id": conversation_id,
            }

        except Exception as e:
            logger.error(f"Error creating conversation: {str(e)}")
            return {"success": False, "error": str(e)}

    async def _add_message(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Add a message to a conversation."""
        from app.database.mongodb import get_database
        from app.database.repositories import MessageRepository

        conversation_id = args.get("conversation_id")
        user_id = args.get("user_id")
        role = args.get("role")  # "user" or "assistant"
        content = args.get("content")

        if not all([conversation_id, user_id, role, content]):
            return {
                "success": False,
                "error": "conversation_id, user_id, role, and content are required",
            }

        try:
            db = await get_database()
            repo = MessageRepository(db)
            message_id = await repo.create(conversation_id, user_id, role, content)

            return {
                "success": True,
                "message_id": message_id,
            }

        except Exception as e:
            logger.error(f"Error adding message: {str(e)}")
            return {"success": False, "error": str(e)}

    async def _get_conversation_history(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Get conversation history."""
        from app.database.mongodb import get_database
        from app.database.repositories import MessageRepository

        conversation_id = args.get("conversation_id")
        if not conversation_id:
            return {"success": False, "error": "conversation_id is required"}

        try:
            db = await get_database()
            repo = MessageRepository(db)
            messages = await repo.list_by_conversation(conversation_id)

            return {
                "success": True,
                "messages": [
                    {
                        "id": msg.id,
                        "role": msg.role,
                        "content": msg.content,
                        "created_at": msg.created_at.isoformat(),
                    }
                    for msg in messages
                ],
            }

        except Exception as e:
            logger.error(f"Error getting conversation history: {str(e)}")
            return {"success": False, "error": str(e)}

    async def _get_query_templates(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Get query templates for common patterns."""
        templates = {
            "top_errors": "FROM logs | STATS count() BY error_type | SORT count() DESC | LIMIT 10",
            "error_by_service": "FROM logs | STATS count() BY service_name, error_type | SORT count() DESC",
            "recent_errors": "FROM logs | WHERE timestamp > now() - 1h | STATS count() BY error_type",
            "error_rate": "FROM logs | STATS count() BY service_name | RENAME count() AS error_count",
            "service_performance": "FROM metrics | STATS avg(response_time) BY service_name",
        }

        return {
            "success": True,
            "templates": templates,
        }

    async def _get_user_permissions(self, args: Dict[str, Any]) -> Dict[str, Any]:
        """Get user permissions based on Azure AD groups."""
        from app.auth.azure_ad import azure_ad_client

        user_id = args.get("user_id")
        access_token = args.get("access_token")

        if not user_id or not access_token:
            return {"success": False, "error": "user_id and access_token are required"}

        try:
            user_info = await azure_ad_client.get_user_info(access_token)
            if user_info:
                return {
                    "success": True,
                    "user_id": user_info.id,
                    "email": user_info.email,
                    "groups": user_info.groups,
                }
            else:
                return {"success": False, "error": "Failed to get user info"}

        except Exception as e:
            logger.error(f"Error getting user permissions: {str(e)}")
            return {"success": False, "error": str(e)}

    # ==================== RESOURCES ====================

    async def _get_index_catalog(self) -> Dict[str, Any]:
        """Get catalog of all available indices."""
        from app.elasticsearch.client import es_client

        try:
            indices = await es_client.get_indices()
            catalog = {}

            for idx in indices[:20]:  # Limit to first 20
                stats = await es_client.get_index_stats(idx)
                if stats:
                    catalog[idx] = {
                        "doc_count": stats.get("doc_count", 0),
                        "size_in_bytes": stats.get("size_in_bytes", 0),
                    }

            return {"success": True, "catalog": catalog}

        except Exception as e:
            logger.error(f"Error getting index catalog: {str(e)}")
            return {"success": False, "error": str(e)}

    async def _get_field_mappings(self) -> Dict[str, Any]:
        """Get field mappings for all indices."""
        from app.elasticsearch.client import es_client

        try:
            indices = await es_client.get_indices()
            mappings = {}

            for idx in indices[:10]:  # Limit to first 10
                metadata = await es_client.get_index_metadata(idx)
                if metadata:
                    mappings[idx] = metadata.get("field_capabilities", {})

            return {"success": True, "mappings": mappings}

        except Exception as e:
            logger.error(f"Error getting field mappings: {str(e)}")
            return {"success": False, "error": str(e)}

    async def _get_query_templates_resource(self) -> Dict[str, Any]:
        """Get query templates as a resource."""
        templates = {
            "error_analysis": {
                "description": "Analyze error patterns",
                "template": "FROM logs | STATS count() BY error_type",
            },
            "service_metrics": {
                "description": "Get service performance metrics",
                "template": "FROM metrics | STATS avg(response_time) BY service_name",
            },
            "user_activity": {
                "description": "Track user activity",
                "template": "FROM events | STATS count() BY user_id",
            },
        }

        return {"success": True, "templates": templates}

    async def _get_audit_logs(self) -> Dict[str, Any]:
        """Get audit logs for compliance."""
        from app.database.mongodb import get_database
        from app.database.repositories import AuditLogRepository

        try:
            db = await get_database()
            repo = AuditLogRepository(db)
            # In real implementation, would get logs for current user
            return {
                "success": True,
                "message": "Audit logs available via API",
            }

        except Exception as e:
            logger.error(f"Error getting audit logs: {str(e)}")
            return {"success": False, "error": str(e)}

    # ==================== MCP PROTOCOL ====================

    async def handle_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """Handle MCP protocol request."""
        method = request.get("method")
        params = request.get("params", {})

        if method == "tools/list":
            return self._list_tools()
        elif method == "tools/call":
            tool_name = params.get("name")
            tool_args = params.get("arguments", {})
            return await self._call_tool(tool_name, tool_args)
        elif method == "resources/list":
            return self._list_resources()
        elif method == "resources/read":
            resource_uri = params.get("uri")
            return await self._read_resource(resource_uri)
        else:
            return {"error": f"Unknown method: {method}"}

    def _list_tools(self) -> Dict[str, Any]:
        """List available tools."""
        tools = [
            Tool(
                name="list_indices",
                description="List all available Elasticsearch indices",
                inputSchema={
                    "type": "object",
                    "properties": {},
                    "required": [],
                },
            ),
            Tool(
                name="get_index_metadata",
                description="Get metadata for a specific index",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "index_name": {"type": "string", "description": "Name of the index"}
                    },
                    "required": ["index_name"],
                },
            ),
            Tool(
                name="generate_esql_query",
                description="Generate ES|QL query from natural language",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "question": {"type": "string", "description": "Natural language question"},
                        "index_name": {
                            "type": "string",
                            "description": "Optional specific index to query",
                        },
                    },
                    "required": ["question"],
                },
            ),
            Tool(
                name="execute_esql_query",
                description="Execute an ES|QL query",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "ES|QL query to execute"}
                    },
                    "required": ["query"],
                },
            ),
            Tool(
                name="summarize_results",
                description="Summarize query results using LLM",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "question": {"type": "string", "description": "Original question"},
                        "results": {"type": "object", "description": "Query results"},
                    },
                    "required": ["question", "results"],
                },
            ),
        ]

        return {
            "tools": [tool.model_dump() for tool in tools],
        }

    async def _call_tool(self, tool_name: str, args: Dict[str, Any]) -> Dict[str, Any]:
        """Call a tool."""
        if tool_name not in self.tools:
            return {"error": f"Unknown tool: {tool_name}"}

        try:
            result = await self.tools[tool_name](args)
            return result
        except Exception as e:
            logger.error(f"Error calling tool {tool_name}: {str(e)}")
            return {"error": str(e)}

    def _list_resources(self) -> Dict[str, Any]:
        """List available resources."""
        resources = [
            Resource(
                uri="index://catalog",
                name="Index Catalog",
                description="Catalog of all available Elasticsearch indices",
            ),
            Resource(
                uri="index://field_mappings",
                name="Field Mappings",
                description="Field mappings for all indices",
            ),
            Resource(
                uri="templates://query_templates",
                name="Query Templates",
                description="Common query templates and patterns",
            ),
        ]

        return {
            "resources": [resource.model_dump() for resource in resources],
        }

    async def _read_resource(self, resource_uri: str) -> Dict[str, Any]:
        """Read a resource."""
        if resource_uri == "index://catalog":
            return await self._get_index_catalog()
        elif resource_uri == "index://field_mappings":
            return await self._get_field_mappings()
        elif resource_uri == "templates://query_templates":
            return await self._get_query_templates_resource()
        else:
            return {"error": f"Unknown resource: {resource_uri}"}


# Global MCP server instance
mcp_server = MCPServer()
