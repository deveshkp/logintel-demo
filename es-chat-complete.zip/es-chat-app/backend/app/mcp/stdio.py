"""MCP stdio transport for running as standalone server."""

import json
import sys
import asyncio
import logging
from typing import Dict, Any
from app.mcp.server import mcp_server

logger = logging.getLogger(__name__)


class StdioTransport:
    """Stdio transport for MCP protocol."""

    def __init__(self):
        """Initialize stdio transport."""
        self.server = mcp_server

    async def run(self):
        """Run the stdio transport."""
        logger.info("Starting MCP stdio transport")

        while True:
            try:
                # Read line from stdin
                line = sys.stdin.readline()
                if not line:
                    break

                # Parse JSON request
                request = json.loads(line)
                logger.debug(f"Received request: {request.get('method')}")

                # Handle request
                response = await self.server.handle_request(request)

                # Send response
                sys.stdout.write(json.dumps(response) + "\n")
                sys.stdout.flush()

            except json.JSONDecodeError as e:
                logger.error(f"Invalid JSON: {str(e)}")
                error_response = {
                    "error": f"Invalid JSON: {str(e)}",
                }
                sys.stdout.write(json.dumps(error_response) + "\n")
                sys.stdout.flush()

            except Exception as e:
                logger.error(f"Error handling request: {str(e)}")
                error_response = {
                    "error": f"Internal error: {str(e)}",
                }
                sys.stdout.write(json.dumps(error_response) + "\n")
                sys.stdout.flush()


async def main():
    """Main entry point for stdio transport."""
    transport = StdioTransport()
    await transport.run()


if __name__ == "__main__":
    asyncio.run(main())
