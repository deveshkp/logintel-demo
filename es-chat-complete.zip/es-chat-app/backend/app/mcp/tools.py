"""MCP Tools implementation for Elasticsearch Chat."""

import json
import logging
from typing import Any, Dict, List, Optional
from datetime import datetime, timedelta

from app.elasticsearch.client import es_client
from app.llm.azure_openai import llm_client
from app.database.mongodb import db_client
from app.database.models import (
    Conversation,
    Message,
    QueryLog,
    AuditLog,
)

logger = logging.getLogger(__name__)

# Query templates for common patterns
QUERY_TEMPLATES = {
    "top_errors": {
        "name": "Top Errors",
        "description": "Show top error patterns",
        "template": "FROM {index} | STATS count() AS errors BY error_type | SORT errors DESC | LIMIT 10",
    },
    "errors_by_service": {
        "name": "Errors by Service",
        "description": "Show errors grouped by service",
        "template": "FROM {index} | STATS count() AS errors BY service_name | SORT errors DESC",
    },
    "service_performance": {
        "name": "Service Performance",
        "description": "Show service performance metrics",
        "template": "FROM {index} | STATS avg(response_time) AS avg_time, max(response_time) AS max_time BY service_name",
    },
    "recent_activity": {
        "name": "Recent Activity",
        "description": "Show recent activity",
        "template": "FROM {index} | SORT @timestamp DESC | LIMIT 100",
    },
}


class MCPTools:
    """MCP Tools implementation."""

    async def list_indices(self) -> Dict[str, Any]:
        """List all available Elasticsearch indices."""
        try:
            indices = await es_client.list_indices()
            return {
                "success": True,
                "indices": indices,
                "count": len(indices),
            }
        except Exception as e:
            logger.error(f"Error listing indices: {str(e)}")
            return {
                "success": False,
                "error": f"Failed to list indices: {str(e)}",
            }

    async def get_index_metadata(self, index_name: str) -> Dict[str, Any]:
        """Get metadata for a specific index."""
        try:
            metadata = await es_client.get_index_metadata(index_name)
            return {
                "success": True,
                "index": index_name,
                "fields": metadata["fields"],
                "field_count": len(metadata["fields"]),
                "properties": metadata.get("properties", {}),
            }
        except Exception as e:
            logger.error(f"Error getting index metadata: {str(e)}")
            return {
                "success": False,
                "error": f"Failed to get index metadata: {str(e)}",
            }

    async def get_index_stats(self, index_name: str) -> Dict[str, Any]:
        """Get statistics for an index."""
        try:
            stats = await es_client.get_index_stats(index_name)
            return {
                "success": True,
                "index": index_name,
                "doc_count": stats.get("doc_count", 0),
                "size_bytes": stats.get("size_bytes", 0),
                "size_mb": stats.get("size_bytes", 0) / (1024 * 1024),
            }
        except Exception as e:
            logger.error(f"Error getting index stats: {str(e)}")
            return {
                "success": False,
                "error": f"Failed to get index stats: {str(e)}",
            }

    async def generate_esql_query(
        self, question: str, index_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """Generate ES|QL query from natural language."""
        try:
            # Get available indices if not specified
            if not index_name:
                indices = await es_client.list_indices()
                if not indices:
                    return {
                        "success": False,
                        "error": "No indices available",
                    }
                index_name = indices[0]

            # Get index metadata for context
            metadata = await es_client.get_index_metadata(index_name)
            fields = metadata["fields"]

            # Build constraint-based prompt
            field_list = "\n".join(
                [f"- {f['name']} ({f['type']}, aggregatable: {f.get('aggregatable', False)})"
                 for f in fields[:20]]  # Limit to 20 fields
            )

            prompt = f"""You are an Elasticsearch query expert. Generate an ES|QL query for this question.

Index: {index_name}
Available fields:
{field_list}

Question: {question}

Rules:
1. Use ONLY the fields listed above
2. Use FROM {index_name} as the starting clause
3. Use STATS for aggregations
4. Use SORT for ordering
5. Use LIMIT to restrict results
6. Return valid ES|QL syntax only
7. Provide a confidence score (0-1) for your query

Format your response as JSON:
{{
  "query": "FROM {index_name} | ...",
  "confidence": 0.95,
  "reasoning": "explanation of the query",
  "fields_used": ["field1", "field2"]
}}"""

            # Call LLM
            response = await llm_client.generate_query(prompt)
            
            # Parse response
            try:
                result = json.loads(response)
            except json.JSONDecodeError:
                # Try to extract JSON from response
                start = response.find("{")
                end = response.rfind("}") + 1
                if start >= 0 and end > start:
                    result = json.loads(response[start:end])
                else:
                    result = {
                        "query": response,
                        "confidence": 0.5,
                        "reasoning": "Extracted from LLM response",
                        "fields_used": [],
                    }

            return {
                "success": True,
                "query_generation": {
                    "selected_index": index_name,
                    "query": result.get("query", ""),
                    "confidence": result.get("confidence", 0.5),
                    "reasoning": result.get("reasoning", ""),
                    "fields_used": result.get("fields_used", []),
                    "warnings": [],
                },
            }
        except Exception as e:
            logger.error(f"Error generating query: {str(e)}")
            return {
                "success": False,
                "error": f"Failed to generate query: {str(e)}",
            }

    async def execute_esql_query(self, query: str) -> Dict[str, Any]:
        """Execute an ES|QL query."""
        try:
            import time
            start_time = time.time()

            # Validate query first
            validation = await self.validate_esql_query(query)
            if not validation.get("success"):
                return {
                    "success": False,
                    "error": f"Query validation failed: {validation.get('error')}",
                }

            # Execute query
            results = await es_client.execute_esql_query(query)

            execution_time_ms = int((time.time() - start_time) * 1000)

            return {
                "success": True,
                "query_execution": {
                    "columns": results.get("columns", []),
                    "rows": results.get("rows", []),
                    "row_count": len(results.get("rows", [])),
                    "execution_time_ms": execution_time_ms,
                },
            }
        except Exception as e:
            logger.error(f"Error executing query: {str(e)}")
            return {
                "success": False,
                "error": f"Failed to execute query: {str(e)}",
            }

    async def validate_esql_query(self, query: str) -> Dict[str, Any]:
        """Validate ES|QL query syntax."""
        try:
            # Basic syntax validation
            if not query.strip().upper().startswith("FROM"):
                return {
                    "success": False,
                    "error": "Query must start with FROM clause",
                }

            # Try to parse with Elasticsearch
            is_valid = await es_client.validate_esql_query(query)

            if is_valid:
                return {
                    "success": True,
                    "valid": True,
                }
            else:
                return {
                    "success": False,
                    "error": "Invalid ES|QL syntax",
                }
        except Exception as e:
            logger.error(f"Error validating query: {str(e)}")
            return {
                "success": False,
                "error": f"Validation error: {str(e)}",
            }

    async def summarize_results(
        self, question: str, results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Summarize query results using LLM."""
        try:
            # Format results for LLM
            columns = results.get("columns", [])
            rows = results.get("rows", [])[:10]  # Limit to 10 rows for context

            results_text = "Columns: " + ", ".join(columns) + "\n"
            results_text += "Results:\n"
            for row in rows:
                results_text += str(row) + "\n"

            prompt = f"""Summarize these Elasticsearch query results in natural language.

Question: {question}

Results:
{results_text}

Provide a clear, concise summary that answers the question. Focus on key insights and patterns."""

            # Call LLM
            summary = await llm_client.summarize_results(prompt)

            return {
                "success": True,
                "result_summary": summary,
                "tokens_used": 0,  # TODO: Get from LLM response
            }
        except Exception as e:
            logger.error(f"Error summarizing results: {str(e)}")
            return {
                "success": False,
                "error": f"Failed to summarize results: {str(e)}",
            }

    async def create_conversation(
        self, user_id: str, title: str
    ) -> Dict[str, Any]:
        """Create a new conversation."""
        try:
            conversation = Conversation(
                user_id=user_id,
                title=title,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )

            result = await db_client.conversations.insert_one(
                conversation.dict()
            )

            return {
                "success": True,
                "conversation_id": str(result.inserted_id),
                "title": title,
            }
        except Exception as e:
            logger.error(f"Error creating conversation: {str(e)}")
            return {
                "success": False,
                "error": f"Failed to create conversation: {str(e)}",
            }

    async def add_message(
        self,
        conversation_id: str,
        user_id: str,
        role: str,
        content: str,
    ) -> Dict[str, Any]:
        """Add a message to a conversation."""
        try:
            message = Message(
                conversation_id=conversation_id,
                user_id=user_id,
                role=role,
                content=content,
                created_at=datetime.utcnow(),
            )

            result = await db_client.messages.insert_one(message.dict())

            return {
                "success": True,
                "message_id": str(result.inserted_id),
            }
        except Exception as e:
            logger.error(f"Error adding message: {str(e)}")
            return {
                "success": False,
                "error": f"Failed to add message: {str(e)}",
            }

    async def get_conversation_history(
        self, conversation_id: str
    ) -> Dict[str, Any]:
        """Get all messages in a conversation."""
        try:
            messages = await db_client.messages.find(
                {"conversation_id": conversation_id}
            ).to_list(None)

            return {
                "success": True,
                "conversation_id": conversation_id,
                "messages": messages,
                "message_count": len(messages),
            }
        except Exception as e:
            logger.error(f"Error getting conversation history: {str(e)}")
            return {
                "success": False,
                "error": f"Failed to get conversation history: {str(e)}",
            }

    async def get_query_templates(self) -> Dict[str, Any]:
        """Get pre-built query templates."""
        try:
            return {
                "success": True,
                "templates": QUERY_TEMPLATES,
                "template_count": len(QUERY_TEMPLATES),
            }
        except Exception as e:
            logger.error(f"Error getting templates: {str(e)}")
            return {
                "success": False,
                "error": f"Failed to get templates: {str(e)}",
            }

    async def get_user_permissions(
        self, user_id: str, access_token: Optional[str] = None
    ) -> Dict[str, Any]:
        """Get user's Azure AD groups and permissions."""
        try:
            # TODO: Implement Azure AD group fetching
            # For now, return mock data
            return {
                "success": True,
                "user_id": user_id,
                "groups": [
                    "es-access-logs-prod",
                    "es-access-metrics-prod",
                ],
                "accessible_indices": [
                    "logs_prod",
                    "metrics_prod",
                ],
            }
        except Exception as e:
            logger.error(f"Error getting user permissions: {str(e)}")
            return {
                "success": False,
                "error": f"Failed to get user permissions: {str(e)}",
            }


# Global instance
mcp_tools = MCPTools()
