"""MCP (Model Context Protocol) server implementation."""

from app.mcp.server import mcp_server

__all__ = ["mcp_server"]
