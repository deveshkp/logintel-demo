"""Azure OpenAI integration for query generation and result summarization."""

import logging
import json
from typing import Optional, Dict, Any
from openai import AzureOpenAI
from app.config import settings

logger = logging.getLogger(__name__)


class AzureOpenAIClient:
    """Client for Azure OpenAI API."""

    def __init__(self):
        """Initialize Azure OpenAI client."""
        self.client = AzureOpenAI(
            api_key=settings.azure_openai_api_key,
            api_version="2024-02-15-preview",
            azure_endpoint=settings.azure_openai_endpoint,
        )
        self.deployment_name = settings.azure_openai_deployment_name

    async def generate_esql_query(
        self,
        user_question: str,
        index_metadata: Dict[str, Any],
        available_indices: list[str],
    ) -> Dict[str, Any]:
        """
        Generate ES|QL query from natural language question.

        Args:
            user_question: User's natural language question
            index_metadata: Metadata about available indices and fields
            available_indices: List of available index names

        Returns:
            Dict with generated query, selected index, confidence, and reasoning
        """
        try:
            # Build constraint-based prompt
            prompt = self._build_query_generation_prompt(
                user_question, index_metadata, available_indices
            )

            response = self.client.chat.completions.create(
                model=self.deployment_name,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert Elasticsearch query generator. Generate only valid ES|QL queries. Always respond with valid JSON.",
                    },
                    {"role": "user", "content": prompt},
                ],
                temperature=0.2,  # Low temperature for consistency
                response_format={"type": "json_object"},
            )

            result_text = response.choices[0].message.content
            result = json.loads(result_text)

            logger.info(f"Generated ES|QL query with confidence {result.get('confidence', 0)}")
            return result

        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse LLM response as JSON: {str(e)}")
            return {
                "query": None,
                "index": None,
                "confidence": 0.0,
                "error": "Invalid response format",
            }
        except Exception as e:
            logger.error(f"Error generating ES|QL query: {str(e)}")
            return {
                "query": None,
                "index": None,
                "confidence": 0.0,
                "error": str(e),
            }

    async def summarize_results(
        self, user_question: str, query_results: Dict[str, Any]
    ) -> str:
        """
        Summarize query results in natural language.

        Args:
            user_question: Original user question
            query_results: Results from ES|QL query

        Returns:
            Natural language summary
        """
        try:
            # Extract columns and rows from results
            columns = query_results.get("columns", [])
            rows = query_results.get("rows", [])

            # Limit rows for summarization
            rows_to_summarize = rows[:100]  # Use first 100 rows

            prompt = f"""
Summarize the following Elasticsearch query results in a clear, concise way.

User Question: {user_question}

Query Results:
Columns: {json.dumps(columns)}
Rows (first {len(rows_to_summarize)}): {json.dumps(rows_to_summarize)}
Total Rows: {len(rows)}

Provide a natural language summary that:
1. Directly answers the user's question
2. Highlights key findings
3. Mentions the total number of results if relevant
4. Uses clear formatting (lists, numbers, etc.)
"""

            response = self.client.chat.completions.create(
                model=self.deployment_name,
                messages=[
                    {
                        "role": "system",
                        "content": "You are a data analyst. Summarize Elasticsearch query results clearly and concisely.",
                    },
                    {"role": "user", "content": prompt},
                ],
                temperature=0.3,
            )

            summary = response.choices[0].message.content
            logger.info("Successfully summarized query results")
            return summary

        except Exception as e:
            logger.error(f"Error summarizing results: {str(e)}")
            return f"Error summarizing results: {str(e)}"

    def _build_query_generation_prompt(
        self,
        user_question: str,
        index_metadata: Dict[str, Any],
        available_indices: list[str],
    ) -> str:
        """
        Build constraint-based prompt for query generation.

        Args:
            user_question: User's question
            index_metadata: Index metadata
            available_indices: Available indices

        Returns:
            Formatted prompt with constraints
        """
        # Extract field information
        fields_info = []
        if "fields" in index_metadata:
            for field_name, field_info in index_metadata["fields"].items():
                field_type = field_info.get("type", "unknown")
                aggregatable = field_info.get("aggregatable", False)
                searchable = field_info.get("searchable", False)
                fields_info.append(
                    f"- {field_name} (type: {field_type}, aggregatable: {aggregatable}, searchable: {searchable})"
                )

        prompt = f"""
Generate an ES|QL query for the following question.

CONSTRAINTS - FOLLOW EXACTLY:
1. Use ONLY these indices: {', '.join(available_indices)}
2. Use ONLY these fields:
{chr(10).join(fields_info[:20])}  # Limit to first 20 fields
3. Query must start with FROM
4. Use STATS for aggregations
5. Only aggregate on fields marked aggregatable: true
6. Use SORT for ordering
7. Use LIMIT for result limits

User Question: {user_question}

Respond with ONLY valid JSON in this format:
{{
    "selected_index": "index_name",
    "query": "FROM index_name | STATS ...",
    "confidence": 0.95,
    "reasoning": "Brief explanation of query",
    "fields_used": ["field1", "field2"],
    "warnings": []
}}

Important:
- confidence must be between 0 and 1
- If you cannot generate a valid query, set confidence to 0 and include error in warnings
- Never use fields not in the provided list
- Never use indices not in the provided list
"""
        return prompt


# Global Azure OpenAI client instance
llm_client = AzureOpenAIClient()
