"""Query validation and hallucination prevention service."""

import re
import logging
from typing import Dict, List, Any, Tuple

logger = logging.getLogger(__name__)


class QueryValidator:
    """Validates ES|QL queries and prevents hallucinations."""

    # ES|QL keywords
    VALID_KEYWORDS = {
        "FROM", "STATS", "SORT", "LIMIT", "WHERE", "BY",
        "DESC", "ASC", "AND", "OR", "NOT", "IN",
    }

    # Common aggregation functions
    AGGREGATION_FUNCTIONS = {
        "count", "sum", "avg", "min", "max", "cardinality",
        "percentiles", "stats", "extended_stats",
    }

    def __init__(self):
        """Initialize validator."""
        pass

    def validate_query(self, query: str) -> Tuple[bool, str]:
        """Validate ES|QL query syntax."""
        if not query or not isinstance(query, str):
            return False, "Query must be a non-empty string"

        query = query.strip()

        # Check if query starts with FROM
        if not query.upper().startswith("FROM"):
            return False, "Query must start with FROM clause"

        # Check for basic syntax issues
        if query.count("(") != query.count(")"):
            return False, "Unbalanced parentheses"

        if query.count("|") < 1:
            return False, "Query must contain at least one pipe (|)"

        # Check for SQL injection patterns
        if self._has_injection_patterns(query):
            return False, "Query contains suspicious patterns"

        return True, "Query is valid"

    def validate_fields(
        self, query: str, available_fields: List[str]
    ) -> Tuple[bool, str, List[str]]:
        """Validate that all fields in query exist in index."""
        # Extract field names from query
        fields_in_query = self._extract_fields(query)

        # Check if all fields exist
        missing_fields = [f for f in fields_in_query if f not in available_fields]

        if missing_fields:
            return False, f"Unknown fields: {', '.join(missing_fields)}", missing_fields

        return True, "All fields are valid", fields_in_query

    def validate_aggregations(
        self, query: str, field_aggregatability: Dict[str, bool]
    ) -> Tuple[bool, str]:
        """Validate that aggregatable fields are used correctly."""
        # Check if query uses STATS
        if "STATS" not in query.upper():
            return True, "No aggregations in query"

        # Extract fields used in STATS
        stats_fields = self._extract_stats_fields(query)

        # Check if all STATS fields are aggregatable
        for field in stats_fields:
            if field not in field_aggregatability:
                continue  # Field might be an aggregation function

            if not field_aggregatability.get(field, False):
                return False, f"Field '{field}' is not aggregatable"

        return True, "Aggregations are valid"

    def suggest_corrections(
        self, query: str, error: str, available_fields: List[str]
    ) -> List[str]:
        """Suggest corrections for invalid queries."""
        suggestions = []

        if "Unknown fields" in error:
            # Extract missing fields and suggest similar ones
            missing = re.findall(r"'([^']+)'", error)
            for field in missing:
                similar = self._find_similar_fields(field, available_fields)
                if similar:
                    suggestions.append(f"Did you mean '{similar}'?")

        if "Unbalanced parentheses" in error:
            suggestions.append("Check that all opening parentheses have closing ones")

        if not query.upper().startswith("FROM"):
            suggestions.append("Queries must start with: FROM <index_name>")

        return suggestions

    def _extract_fields(self, query: str) -> List[str]:
        """Extract field names from query."""
        fields = set()

        # Match field names (word characters, dots, underscores)
        pattern = r'\b([a-zA-Z_][a-zA-Z0-9_\.]*)\b'
        matches = re.findall(pattern, query)

        for match in matches:
            # Skip keywords and functions
            if match.upper() not in self.VALID_KEYWORDS and \
               match.lower() not in self.AGGREGATION_FUNCTIONS:
                fields.add(match)

        return list(fields)

    def _extract_stats_fields(self, query: str) -> List[str]:
        """Extract fields used in STATS clause."""
        fields = []

        # Find STATS clause
        stats_match = re.search(r'STATS\s+(.+?)(?:\||$)', query, re.IGNORECASE)
        if not stats_match:
            return fields

        stats_clause = stats_match.group(1)

        # Extract BY clause fields
        by_match = re.search(r'BY\s+(.+?)(?:\||$)', stats_clause, re.IGNORECASE)
        if by_match:
            by_clause = by_match.group(1)
            by_fields = [f.strip() for f in by_clause.split(",")]
            fields.extend(by_fields)

        return fields

    def _has_injection_patterns(self, query: str) -> bool:
        """Check for SQL injection patterns."""
        dangerous_patterns = [
            r";\s*DROP",
            r";\s*DELETE",
            r";\s*INSERT",
            r";\s*UPDATE",
            r"--\s*",
            r"/\*.*\*/",
        ]

        for pattern in dangerous_patterns:
            if re.search(pattern, query, re.IGNORECASE):
                return True

        return False

    def _find_similar_fields(self, field: str, available_fields: List[str]) -> str:
        """Find similar field names using simple string matching."""
        # Simple similarity check
        field_lower = field.lower()

        for available in available_fields:
            if field_lower in available.lower() or available.lower() in field_lower:
                return available

        # If no match, return first available field
        return available_fields[0] if available_fields else ""


# Global instance
query_validator = QueryValidator()
