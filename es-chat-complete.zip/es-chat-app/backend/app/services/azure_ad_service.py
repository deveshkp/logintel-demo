"""Azure Entra AD authentication and group management service."""

import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta

from app.database.mongodb import db_client
from app.config import settings

logger = logging.getLogger(__name__)

# Group cache TTL in hours
GROUP_CACHE_TTL_HOURS = 1


class AzureADService:
    """Manages Azure AD authentication and group membership."""

    async def get_user_groups(
        self, user_id: str, access_token: Optional[str] = None
    ) -> List[str]:
        """Get user's Azure AD groups."""
        # Try to get from cache first
        cached_groups = await self._get_cached_groups(user_id)
        if cached_groups:
            logger.info(f"Using cached groups for user {user_id}")
            return cached_groups

        # TODO: Implement actual Azure AD API call
        # For now, return mock groups
        groups = [
            "es-access-logs-prod",
            "es-access-metrics-prod",
        ]

        # Cache the groups
        await self._cache_groups(user_id, groups)

        return groups

    async def get_user_accessible_indices(
        self, user_id: str, access_token: Optional[str] = None
    ) -> List[str]:
        """Get indices accessible to user based on group membership."""
        groups = await self.get_user_groups(user_id, access_token)

        # Get group-to-index mappings
        indices = set()
        for group in groups:
            mapping = await self._get_group_index_mapping(group)
            if mapping:
                indices.update(mapping)

        return list(indices)

    async def validate_index_access(
        self, user_id: str, index_name: str, access_token: Optional[str] = None
    ) -> bool:
        """Check if user has access to specific index."""
        accessible_indices = await self.get_user_accessible_indices(
            user_id, access_token
        )
        return index_name in accessible_indices

    async def add_group_index_mapping(
        self, group_name: str, index_names: List[str]
    ) -> bool:
        """Add mapping between Azure AD group and indices."""
        try:
            await db_client.group_index_mappings.update_one(
                {"group_name": group_name},
                {
                    "$set": {
                        "group_name": group_name,
                        "indices": index_names,
                        "updated_at": datetime.utcnow(),
                    }
                },
                upsert=True,
            )
            logger.info(f"Added mapping for group {group_name}")
            return True
        except Exception as e:
            logger.error(f"Error adding group mapping: {str(e)}")
            return False

    async def get_all_group_mappings(self) -> Dict[str, List[str]]:
        """Get all group-to-index mappings."""
        try:
            mappings = await db_client.group_index_mappings.find({}).to_list(None)
            result = {}
            for mapping in mappings:
                result[mapping["group_name"]] = mapping.get("indices", [])
            return result
        except Exception as e:
            logger.error(f"Error getting group mappings: {str(e)}")
            return {}

    async def log_access(
        self,
        user_id: str,
        index_name: str,
        query: str,
        success: bool,
        error: Optional[str] = None,
    ) -> bool:
        """Log user access for audit trail."""
        try:
            audit_log = {
                "user_id": user_id,
                "index_name": index_name,
                "query": query[:500],  # Limit query length
                "success": success,
                "error": error,
                "timestamp": datetime.utcnow(),
            }
            await db_client.audit_logs.insert_one(audit_log)
            return True
        except Exception as e:
            logger.error(f"Error logging access: {str(e)}")
            return False

    async def get_audit_logs(
        self,
        user_id: Optional[str] = None,
        index_name: Optional[str] = None,
        days: int = 7,
    ) -> List[Dict[str, Any]]:
        """Get audit logs for compliance."""
        try:
            query = {
                "timestamp": {
                    "$gte": datetime.utcnow() - timedelta(days=days)
                }
            }

            if user_id:
                query["user_id"] = user_id

            if index_name:
                query["index_name"] = index_name

            logs = await db_client.audit_logs.find(query).to_list(None)
            return logs
        except Exception as e:
            logger.error(f"Error getting audit logs: {str(e)}")
            return []

    async def _get_cached_groups(self, user_id: str) -> Optional[List[str]]:
        """Get user groups from cache."""
        try:
            cached = await db_client.user_group_cache.find_one(
                {"user_id": user_id}
            )

            if not cached:
                return None

            # Check if cache is expired
            cached_at = cached.get("cached_at")
            if not cached_at:
                return None

            age = datetime.utcnow() - cached_at
            if age > timedelta(hours=GROUP_CACHE_TTL_HOURS):
                # Cache expired, delete it
                await db_client.user_group_cache.delete_one(
                    {"user_id": user_id}
                )
                return None

            return cached.get("groups")
        except Exception as e:
            logger.error(f"Error getting cached groups: {str(e)}")
            return None

    async def _cache_groups(self, user_id: str, groups: List[str]) -> bool:
        """Cache user groups."""
        try:
            await db_client.user_group_cache.update_one(
                {"user_id": user_id},
                {
                    "$set": {
                        "user_id": user_id,
                        "groups": groups,
                        "cached_at": datetime.utcnow(),
                    }
                },
                upsert=True,
            )
            return True
        except Exception as e:
            logger.error(f"Error caching groups: {str(e)}")
            return False

    async def _get_group_index_mapping(self, group_name: str) -> Optional[List[str]]:
        """Get indices for a group."""
        try:
            mapping = await db_client.group_index_mappings.find_one(
                {"group_name": group_name}
            )
            if mapping:
                return mapping.get("indices", [])
            return None
        except Exception as e:
            logger.error(f"Error getting group mapping: {str(e)}")
            return None


# Global instance
azure_ad_service = AzureADService()
