"""Metadata caching service with TTL."""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional

from app.elasticsearch.client import es_client
from app.database.mongodb import db_client

logger = logging.getLogger(__name__)

# Cache TTL in hours
CACHE_TTL_HOURS = 24


class MetadataCache:
    """Manages metadata caching with TTL."""

    async def get_index_metadata(self, index_name: str) -> Optional[Dict[str, Any]]:
        """Get index metadata from cache or fetch fresh."""
        # Try to get from cache
        cached = await self._get_cached_metadata(index_name)
        if cached:
            logger.info(f"Using cached metadata for {index_name}")
            return cached

        # Fetch fresh metadata
        logger.info(f"Fetching fresh metadata for {index_name}")
        metadata = await es_client.get_index_metadata(index_name)

        # Store in cache
        await self._cache_metadata(index_name, metadata)

        return metadata

    async def get_all_indices_metadata(self) -> Dict[str, Dict[str, Any]]:
        """Get metadata for all indices."""
        indices = await es_client.list_indices()
        metadata = {}

        for index in indices:
            try:
                meta = await self.get_index_metadata(index)
                if meta:
                    metadata[index] = meta
            except Exception as e:
                logger.error(f"Error getting metadata for {index}: {str(e)}")

        return metadata

    async def refresh_all_metadata(self) -> Dict[str, bool]:
        """Force refresh all metadata."""
        indices = await es_client.list_indices()
        results = {}

        for index in indices:
            try:
                metadata = await es_client.get_index_metadata(index)
                await self._cache_metadata(index, metadata)
                results[index] = True
                logger.info(f"Refreshed metadata for {index}")
            except Exception as e:
                logger.error(f"Error refreshing metadata for {index}: {str(e)}")
                results[index] = False

        return results

    async def invalidate_cache(self, index_name: Optional[str] = None) -> bool:
        """Invalidate cache for specific index or all."""
        try:
            if index_name:
                await db_client.metadata_cache.delete_one({"index_name": index_name})
                logger.info(f"Invalidated cache for {index_name}")
            else:
                await db_client.metadata_cache.delete_many({})
                logger.info("Invalidated all metadata cache")
            return True
        except Exception as e:
            logger.error(f"Error invalidating cache: {str(e)}")
            return False

    async def _get_cached_metadata(
        self, index_name: str
    ) -> Optional[Dict[str, Any]]:
        """Get metadata from MongoDB cache."""
        try:
            cached = await db_client.metadata_cache.find_one(
                {"index_name": index_name}
            )

            if not cached:
                return None

            # Check if cache is expired
            cached_at = cached.get("cached_at")
            if not cached_at:
                return None

            age = datetime.utcnow() - cached_at
            if age > timedelta(hours=CACHE_TTL_HOURS):
                # Cache expired, delete it
                await db_client.metadata_cache.delete_one(
                    {"index_name": index_name}
                )
                return None

            return cached.get("metadata")
        except Exception as e:
            logger.error(f"Error getting cached metadata: {str(e)}")
            return None

    async def _cache_metadata(
        self, index_name: str, metadata: Dict[str, Any]
    ) -> bool:
        """Store metadata in MongoDB cache."""
        try:
            await db_client.metadata_cache.update_one(
                {"index_name": index_name},
                {
                    "$set": {
                        "index_name": index_name,
                        "metadata": metadata,
                        "cached_at": datetime.utcnow(),
                    }
                },
                upsert=True,
            )
            return True
        except Exception as e:
            logger.error(f"Error caching metadata: {str(e)}")
            return False


# Global instance
metadata_cache = MetadataCache()
