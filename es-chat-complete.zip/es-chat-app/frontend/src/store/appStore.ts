import { create } from 'zustand';

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt: Date;
  debugInfo?: DebugInfo;
}

export interface DebugInfo {
  llmPrompt?: string;
  llmResponse?: string;
  esqlQuery?: string;
  tokensUsed?: number;
  executionTimeMs?: number;
  queryConfidence?: number;
}

export interface Conversation {
  id: string;
  title: string;
  createdAt: Date;
  updatedAt: Date;
  isPinned: boolean;
  messageCount: number;
}

interface AppStore {
  // Theme
  isDarkMode: boolean;
  setIsDarkMode: (isDark: boolean) => void;

  // Conversations
  conversations: Conversation[];
  currentConversationId: string | null;
  setConversations: (conversations: Conversation[]) => void;
  setCurrentConversation: (id: string) => void;
  addConversation: (conversation: Conversation) => void;

  // Messages
  messages: Message[];
  setMessages: (messages: Message[]) => void;
  addMessage: (message: Message) => void;

  // UI State
  isDebugPanelOpen: boolean;
  setIsDebugPanelOpen: (isOpen: boolean) => void;
  isLoading: boolean;
  setIsLoading: (isLoading: boolean) => void;
  error: string | null;
  setError: (error: string | null) => void;

  // User
  userId: string;
  setUserId: (id: string) => void;
}

export const useAppStore = create<AppStore>((set) => ({
  // Theme
  isDarkMode: true,
  setIsDarkMode: (isDark) => set({ isDarkMode: isDark }),

  // Conversations
  conversations: [],
  currentConversationId: null,
  setConversations: (conversations) => set({ conversations }),
  setCurrentConversation: (id) => set({ currentConversationId: id }),
  addConversation: (conversation) =>
    set((state) => ({
      conversations: [conversation, ...state.conversations],
    })),

  // Messages
  messages: [],
  setMessages: (messages) => set({ messages }),
  addMessage: (message) =>
    set((state) => ({
      messages: [...state.messages, message],
    })),

  // UI State
  isDebugPanelOpen: false,
  setIsDebugPanelOpen: (isOpen) => set({ isDebugPanelOpen: isOpen }),
  isLoading: false,
  setIsLoading: (isLoading) => set({ isLoading }),
  error: null,
  setError: (error) => set({ error }),

  // User
  userId: 'user-' + Math.random().toString(36).substr(2, 9),
  setUserId: (id) => set({ userId: id }),
}));
