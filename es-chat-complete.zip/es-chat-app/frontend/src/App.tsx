import React, { useEffect, useRef } from 'react';
import { useAppStore } from '@/store/appStore';
import { Sidebar } from '@/components/Sidebar';
import { ChatMessage } from '@/components/ChatMessage';
import { ChatInput } from '@/components/ChatInput';
import { DebugPanel } from '@/components/DebugPanel';
import { Bug, Moon, Sun } from 'lucide-react';
import apiService from '@/services/api';

function App() {
  const {
    isDarkMode,
    setIsDarkMode,
    conversations,
    currentConversationId,
    messages,
    isLoading,
    setIsLoading,
    error,
    setError,
    isDebugPanelOpen,
    setIsDebugPanelOpen,
    setConversations,
    setCurrentConversation,
    addConversation,
    setMessages,
    addMessage,
  } = useAppStore();

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load conversations on mount
  useEffect(() => {
    loadConversations();
  }, []);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Apply dark mode class to document
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.remove('light');
    } else {
      document.documentElement.classList.add('light');
    }
  }, [isDarkMode]);

  const loadConversations = async () => {
    try {
      // TODO: Load conversations from backend
      // For now, create a default conversation
      const defaultConv = {
        id: 'conv-1',
        title: 'New Conversation',
        createdAt: new Date(),
        updatedAt: new Date(),
        isPinned: false,
        messageCount: 0,
      };
      setConversations([defaultConv]);
      setCurrentConversation(defaultConv.id);
    } catch (err) {
      setError('Failed to load conversations');
    }
  };

  const handleNewConversation = async () => {
    try {
      const newConv = {
        id: `conv-${Date.now()}`,
        title: 'New Conversation',
        createdAt: new Date(),
        updatedAt: new Date(),
        isPinned: false,
        messageCount: 0,
      };
      addConversation(newConv);
      setCurrentConversation(newConv.id);
      setMessages([]);
    } catch (err) {
      setError('Failed to create conversation');
    }
  };

  const handleSendMessage = async (content: string) => {
    if (!currentConversationId) return;

    try {
      setIsLoading(true);
      setError(null);

      // Add user message
      const userMessage = {
        id: `msg-${Date.now()}`,
        role: 'user' as const,
        content,
        createdAt: new Date(),
      };
      addMessage(userMessage);

      // Generate ES|QL query
      const queryResult = await apiService.generateESQLQuery(content);
      if (!queryResult.success) {
        throw new Error(queryResult.error || 'Failed to generate query');
      }

      const queryData = queryResult.query_generation;

      // Execute query
      const execResult = await apiService.executeESQLQuery(queryData.query);
      if (!execResult.success) {
        throw new Error(execResult.error || 'Failed to execute query');
      }

      // Summarize results
      const summaryResult = await apiService.summarizeResults(
        content,
        execResult.query_execution
      );
      if (!summaryResult.success) {
        throw new Error(summaryResult.error || 'Failed to summarize results');
      }

      // Add assistant message with debug info
      const assistantMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'assistant' as const,
        content: summaryResult.result_summary,
        createdAt: new Date(),
        debugInfo: {
          esqlQuery: queryData.query,
          queryConfidence: queryData.confidence,
          executionTimeMs: execResult.execution_time_ms || 0,
          tokensUsed: summaryResult.tokens_used || 0,
          llmPrompt: queryData.reasoning,
          llmResponse: summaryResult.result_summary,
        },
      };
      addMessage(assistantMessage);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
      const errorMessage = {
        id: `msg-${Date.now()}`,
        role: 'assistant' as const,
        content: `Error: ${err instanceof Error ? err.message : 'An error occurred'}`,
        createdAt: new Date(),
      };
      addMessage(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={`flex h-screen ${isDarkMode ? '' : 'light'}`}>
      {/* Sidebar */}
      <Sidebar
        conversations={conversations}
        currentConversationId={currentConversationId}
        onSelectConversation={setCurrentConversation}
        onNewConversation={handleNewConversation}
        onDeleteConversation={(id) => {
          // TODO: Implement delete
        }}
        onTogglePin={(id) => {
          // TODO: Implement pin toggle
        }}
      />

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-dark-bg">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-dark-border">
          <h1 className="text-xl font-semibold text-accent">
            Elasticsearch Chat
          </h1>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsDebugPanelOpen(!isDebugPanelOpen)}
              className={`p-2 rounded hover:bg-dark-surface transition-colors ${
                isDebugPanelOpen ? 'bg-dark-surface text-accent' : ''
              }`}
              title="Toggle debug panel"
            >
              <Bug size={20} />
            </button>
            <button
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2 rounded hover:bg-dark-surface transition-colors"
              title="Toggle dark mode"
            >
              {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 ? (
            <div className="flex items-center justify-center h-full text-center">
              <div>
                <h2 className="text-2xl font-bold text-accent mb-2">
                  Welcome to Elasticsearch Chat
                </h2>
                <p className="text-gray-400">
                  Ask questions about your data using natural language
                </p>
              </div>
            </div>
          ) : (
            <>
              {messages.map((message) => (
                <ChatMessage key={message.id} message={message} />
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-dark-surface rounded p-4 text-accent">
                    <span className="loading-dots">Processing</span>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </>
          )}
        </div>

        {/* Error message */}
        {error && (
          <div className="mx-4 mb-4 p-3 bg-error/20 border border-error rounded text-error text-sm">
            {error}
          </div>
        )}

        {/* Input */}
        <ChatInput
          onSend={handleSendMessage}
          isLoading={isLoading}
          placeholder="Ask about your data... (Ctrl+Enter to send)"
        />
      </div>

      {/* Debug Panel */}
      {isDebugPanelOpen && (
        <DebugPanel
          isOpen={isDebugPanelOpen}
          onClose={() => setIsDebugPanelOpen(false)}
          messages={messages}
        />
      )}
    </div>
  );
}

export default App;
