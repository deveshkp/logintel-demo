import axios from 'axios';

const API_BASE_URL = '/api/mcp';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export interface MCPToolResult {
  success: boolean;
  error?: string;
  [key: string]: any;
}

export interface QueryGenerationResult {
  selected_index: string;
  query: string;
  confidence: number;
  reasoning: string;
  fields_used: string[];
  warnings: string[];
}

export interface QueryExecutionResult {
  columns: string[];
  rows: any[][];
}

export const apiService = {
  // Tools
  async listIndices(): Promise<MCPToolResult> {
    const response = await api.post('/tools/list_indices', {});
    return response.data;
  },

  async getIndexMetadata(indexName: string): Promise<MCPToolResult> {
    const response = await api.post('/tools/get_index_metadata', {
      index_name: indexName,
    });
    return response.data;
  },

  async generateESQLQuery(
    question: string,
    indexName?: string
  ): Promise<MCPToolResult> {
    const response = await api.post('/tools/generate_esql_query', {
      question,
      index_name: indexName,
    });
    return response.data;
  },

  async executeESQLQuery(query: string): Promise<MCPToolResult> {
    const response = await api.post('/tools/execute_esql_query', {
      query,
    });
    return response.data;
  },

  async validateESQLQuery(query: string): Promise<MCPToolResult> {
    const response = await api.post('/tools/validate_esql_query', {
      query,
    });
    return response.data;
  },

  async summarizeResults(
    question: string,
    results: QueryExecutionResult
  ): Promise<MCPToolResult> {
    const response = await api.post('/tools/summarize_results', {
      question,
      results,
    });
    return response.data;
  },

  async createConversation(
    userId: string,
    title: string
  ): Promise<MCPToolResult> {
    const response = await api.post('/tools/create_conversation', {
      user_id: userId,
      title,
    });
    return response.data;
  },

  async addMessage(
    conversationId: string,
    userId: string,
    role: 'user' | 'assistant',
    content: string
  ): Promise<MCPToolResult> {
    const response = await api.post('/tools/add_message', {
      conversation_id: conversationId,
      user_id: userId,
      role,
      content,
    });
    return response.data;
  },

  async getConversationHistory(conversationId: string): Promise<MCPToolResult> {
    const response = await api.post('/tools/get_conversation_history', {
      conversation_id: conversationId,
    });
    return response.data;
  },

  async getQueryTemplates(): Promise<MCPToolResult> {
    const response = await api.post('/tools/get_query_templates', {});
    return response.data;
  },

  // Resources
  async listResources(): Promise<MCPToolResult> {
    const response = await api.get('/resources');
    return response.data;
  },

  async readResource(resourceUri: string): Promise<MCPToolResult> {
    const resourcePath = resourceUri.replace('://', '/');
    const response = await api.get(`/resources/${resourcePath}`);
    return response.data;
  },

  async getIndexCatalog(): Promise<MCPToolResult> {
    return this.readResource('index://catalog');
  },

  async getFieldMappings(): Promise<MCPToolResult> {
    return this.readResource('index://field_mappings');
  },
};

export default apiService;
