import React, { useState } from 'react';
import { Plus, Search, Pin, Trash2 } from 'lucide-react';
import { Conversation } from '@/store/appStore';

interface SidebarProps {
  conversations: Conversation[];
  currentConversationId: string | null;
  onSelectConversation: (id: string) => void;
  onNewConversation: () => void;
  onDeleteConversation: (id: string) => void;
  onTogglePin: (id: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  conversations,
  currentConversationId,
  onSelectConversation,
  onNewConversation,
  onDeleteConversation,
  onTogglePin,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  const pinnedConversations = conversations.filter((c) => c.isPinned);
  const unpinnedConversations = conversations.filter((c) => !c.isPinned);

  const filteredPinned = pinnedConversations.filter((c) =>
    c.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredUnpinned = unpinnedConversations.filter((c) =>
    c.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="w-80 bg-dark-surface border-r border-dark-border flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-dark-border">
        <button
          onClick={onNewConversation}
          className="w-full flex items-center justify-center gap-2 bg-accent text-dark-bg rounded py-2 px-4 hover:bg-accent-hover transition-colors font-medium"
        >
          <Plus size={18} />
          New Conversation
        </button>
      </div>

      {/* Search */}
      <div className="p-4 border-b border-dark-border">
        <div className="relative">
          <Search
            size={16}
            className="absolute left-3 top-3 text-gray-500"
          />
          <input
            type="text"
            placeholder="Search..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-dark-bg border border-dark-border rounded pl-10 pr-4 py-2 text-sm text-gray-100 placeholder-gray-500 focus:outline-none focus:border-accent"
          />
        </div>
      </div>

      {/* Conversations List */}
      <div className="flex-1 overflow-y-auto">
        {/* Pinned */}
        {filteredPinned.length > 0 && (
          <div>
            <div className="px-4 py-2 text-xs font-semibold text-gray-500 uppercase">
              Pinned
            </div>
            {filteredPinned.map((conv) => (
              <ConversationItem
                key={conv.id}
                conversation={conv}
                isActive={conv.id === currentConversationId}
                onSelect={() => onSelectConversation(conv.id)}
                onDelete={() => onDeleteConversation(conv.id)}
                onTogglePin={() => onTogglePin(conv.id)}
              />
            ))}
          </div>
        )}

        {/* Unpinned */}
        {filteredUnpinned.length > 0 && (
          <div>
            {filteredPinned.length > 0 && (
              <div className="px-4 py-2 text-xs font-semibold text-gray-500 uppercase mt-2">
                Recent
              </div>
            )}
            {filteredUnpinned.map((conv) => (
              <ConversationItem
                key={conv.id}
                conversation={conv}
                isActive={conv.id === currentConversationId}
                onSelect={() => onSelectConversation(conv.id)}
                onDelete={() => onDeleteConversation(conv.id)}
                onTogglePin={() => onTogglePin(conv.id)}
              />
            ))}
          </div>
        )}

        {/* Empty state */}
        {filteredPinned.length === 0 && filteredUnpinned.length === 0 && (
          <div className="p-4 text-center text-gray-500 text-sm">
            {searchQuery
              ? 'No conversations found'
              : 'No conversations yet. Create one to get started!'}
          </div>
        )}
      </div>
    </div>
  );
};

interface ConversationItemProps {
  conversation: Conversation;
  isActive: boolean;
  onSelect: () => void;
  onDelete: () => void;
  onTogglePin: () => void;
}

const ConversationItem: React.FC<ConversationItemProps> = ({
  conversation,
  isActive,
  onSelect,
  onDelete,
  onTogglePin,
}) => {
  const [isHovering, setIsHovering] = useState(false);

  return (
    <div
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
      onClick={onSelect}
      className={`px-4 py-3 cursor-pointer border-l-4 transition-colors ${
        isActive
          ? 'border-accent bg-dark-bg'
          : 'border-transparent hover:bg-dark-bg'
      }`}
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex-1 min-w-0">
          <div className="text-sm font-medium text-gray-100 truncate">
            {conversation.title}
          </div>
          <div className="text-xs text-gray-500">
            {conversation.messageCount} messages
          </div>
        </div>

        {isHovering && (
          <div className="flex gap-1">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onTogglePin();
              }}
              className="p-1 hover:text-accent transition-colors"
            >
              <Pin size={14} />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onDelete();
              }}
              className="p-1 hover:text-error transition-colors"
            >
              <Trash2 size={14} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Sidebar;
