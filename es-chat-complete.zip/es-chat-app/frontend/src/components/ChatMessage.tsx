import React from 'react';
import Markdown from 'react-markdown';
import { Message } from '@/store/appStore';
import { Copy, ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';

interface ChatMessageProps {
  message: Message;
  onDebugClick?: () => void;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({
  message,
  onDebugClick,
}) => {
  const [isDebugExpanded, setIsDebugExpanded] = useState(false);
  const isUser = message.role === 'user';

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div
      className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-4 animate-fade-in`}
    >
      <div
        className={`max-w-[70%] ${
          isUser
            ? 'bg-accent/20 border-l-4 border-accent'
            : 'bg-dark-surface border-l-4 border-gray-600'
        } rounded p-4`}
      >
        {/* Main message content */}
        <div className="markdown text-sm leading-relaxed">
          <Markdown
            components={{
              code: ({ node, inline, className, children, ...props }) =>
                inline ? (
                  <code
                    className="bg-dark-bg px-2 py-1 rounded text-accent"
                    {...props}
                  >
                    {children}
                  </code>
                ) : (
                  <pre className="bg-dark-bg border border-dark-border rounded p-3 my-2 overflow-x-auto">
                    <code className="text-accent text-xs" {...props}>
                      {children}
                    </code>
                  </pre>
                ),
              blockquote: ({ node, children, ...props }) => (
                <blockquote
                  className="border-l-4 border-accent pl-4 italic text-gray-400 my-2"
                  {...props}
                >
                  {children}
                </blockquote>
              ),
              a: ({ node, children, ...props }) => (
                <a
                  className="text-accent hover:text-accent-hover underline"
                  target="_blank"
                  rel="noopener noreferrer"
                  {...props}
                >
                  {children}
                </a>
              ),
            }}
          >
            {message.content}
          </Markdown>
        </div>

        {/* Timestamp */}
        <div className="text-xs text-gray-500 mt-2">
          {message.createdAt.toLocaleTimeString()}
        </div>

        {/* Debug info toggle */}
        {message.debugInfo && (
          <div className="mt-3 border-t border-dark-border pt-3">
            <button
              onClick={() => setIsDebugExpanded(!isDebugExpanded)}
              className="flex items-center gap-2 text-xs text-accent hover:text-accent-hover transition-colors"
            >
              {isDebugExpanded ? (
                <ChevronUp size={14} />
              ) : (
                <ChevronDown size={14} />
              )}
              Debug Info
            </button>

            {isDebugExpanded && (
              <div className="mt-2 space-y-2 text-xs">
                {message.debugInfo.queryConfidence !== undefined && (
                  <div className="flex justify-between">
                    <span className="text-gray-400">Confidence:</span>
                    <span className="text-accent">
                      {(message.debugInfo.queryConfidence * 100).toFixed(1)}%
                    </span>
                  </div>
                )}

                {message.debugInfo.executionTimeMs !== undefined && (
                  <div className="flex justify-between">
                    <span className="text-gray-400">Latency:</span>
                    <span className="text-accent">
                      {message.debugInfo.executionTimeMs}ms
                    </span>
                  </div>
                )}

                {message.debugInfo.tokensUsed !== undefined && (
                  <div className="flex justify-between">
                    <span className="text-gray-400">Tokens:</span>
                    <span className="text-accent">
                      {message.debugInfo.tokensUsed}
                    </span>
                  </div>
                )}

                {message.debugInfo.esqlQuery && (
                  <div className="mt-2">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-gray-400">ES|QL Query:</span>
                      <button
                        onClick={() =>
                          copyToClipboard(message.debugInfo.esqlQuery || '')
                        }
                        className="text-accent hover:text-accent-hover"
                      >
                        <Copy size={12} />
                      </button>
                    </div>
                    <pre className="bg-dark-bg border border-dark-border rounded p-2 overflow-x-auto text-accent">
                      <code>{message.debugInfo.esqlQuery}</code>
                    </pre>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatMessage;
