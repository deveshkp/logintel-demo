import React, { useState } from 'react';
import { X, Copy, ChevronDown, ChevronUp } from 'lucide-react';
import { Message } from '@/store/appStore';

interface DebugPanelProps {
  isOpen: boolean;
  onClose: () => void;
  messages: Message[];
}

export const DebugPanel: React.FC<DebugPanelProps> = ({
  isOpen,
  onClose,
  messages,
}) => {
  const [activeTab, setActiveTab] = useState<'all' | 'queries' | 'llm'>('all');
  const [expandedLogs, setExpandedLogs] = useState<Set<string>>(new Set());

  const debugMessages = messages.filter((m) => m.debugInfo);

  const filteredMessages = debugMessages.filter((m) => {
    if (activeTab === 'all') return true;
    if (activeTab === 'queries') return m.debugInfo?.esqlQuery;
    if (activeTab === 'llm') return m.debugInfo?.llmResponse;
    return false;
  });

  const toggleExpanded = (messageId: string) => {
    const newSet = new Set(expandedLogs);
    if (newSet.has(messageId)) {
      newSet.delete(messageId);
    } else {
      newSet.add(messageId);
    }
    setExpandedLogs(newSet);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  if (!isOpen) return null;

  return (
    <div className="w-96 bg-dark-surface border-l border-dark-border flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-dark-border">
        <h2 className="font-semibold text-accent">Debug Info</h2>
        <button
          onClick={onClose}
          className="p-1 hover:bg-dark-bg rounded transition-colors"
        >
          <X size={18} />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 px-4 py-2 border-b border-dark-border text-sm">
        <button
          onClick={() => setActiveTab('all')}
          className={`px-3 py-1 rounded transition-colors ${
            activeTab === 'all'
              ? 'bg-accent text-dark-bg'
              : 'text-gray-400 hover:text-gray-200'
          }`}
        >
          All
        </button>
        <button
          onClick={() => setActiveTab('queries')}
          className={`px-3 py-1 rounded transition-colors ${
            activeTab === 'queries'
              ? 'bg-accent text-dark-bg'
              : 'text-gray-400 hover:text-gray-200'
          }`}
        >
          Queries
        </button>
        <button
          onClick={() => setActiveTab('llm')}
          className={`px-3 py-1 rounded transition-colors ${
            activeTab === 'llm'
              ? 'bg-accent text-dark-bg'
              : 'text-gray-400 hover:text-gray-200'
          }`}
        >
          LLM
        </button>
      </div>

      {/* Logs */}
      <div className="flex-1 overflow-y-auto">
        {filteredMessages.length === 0 ? (
          <div className="p-4 text-center text-gray-500 text-sm">
            No debug information available
          </div>
        ) : (
          <div className="space-y-2 p-4">
            {filteredMessages.map((message) => (
              <DebugLogItem
                key={message.id}
                message={message}
                isExpanded={expandedLogs.has(message.id)}
                onToggle={() => toggleExpanded(message.id)}
                onCopy={copyToClipboard}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

interface DebugLogItemProps {
  message: Message;
  isExpanded: boolean;
  onToggle: () => void;
  onCopy: (text: string) => void;
}

const DebugLogItem: React.FC<DebugLogItemProps> = ({
  message,
  isExpanded,
  onToggle,
  onCopy,
}) => {
  const debug = message.debugInfo;

  return (
    <div className="bg-dark-bg border border-dark-border rounded">
      {/* Header */}
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between p-3 hover:bg-dark-surface transition-colors text-left"
      >
        <div className="flex items-center gap-2 flex-1 min-w-0">
          {isExpanded ? (
            <ChevronUp size={16} className="text-accent flex-shrink-0" />
          ) : (
            <ChevronDown size={16} className="text-accent flex-shrink-0" />
          )}
          <div className="min-w-0">
            <div className="text-xs text-gray-400">
              {message.createdAt.toLocaleTimeString()}
            </div>
            {debug?.executionTimeMs && (
              <div className="text-xs text-accent">
                {debug.executionTimeMs}ms
              </div>
            )}
          </div>
        </div>
      </button>

      {/* Content */}
      {isExpanded && (
        <div className="border-t border-dark-border p-3 space-y-3 text-xs">
          {debug?.queryConfidence !== undefined && (
            <div>
              <div className="text-gray-400 mb-1">Confidence</div>
              <div className="text-accent font-mono">
                {(debug.queryConfidence * 100).toFixed(1)}%
              </div>
            </div>
          )}

          {debug?.tokensUsed !== undefined && (
            <div>
              <div className="text-gray-400 mb-1">Tokens</div>
              <div className="text-accent font-mono">{debug.tokensUsed}</div>
            </div>
          )}

          {debug?.esqlQuery && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-gray-400">ES|QL Query</span>
                <button
                  onClick={() => onCopy(debug.esqlQuery || '')}
                  className="text-accent hover:text-accent-hover"
                >
                  <Copy size={12} />
                </button>
              </div>
              <pre className="bg-dark-bg border border-dark-border rounded p-2 overflow-x-auto text-accent font-mono text-xs">
                {debug.esqlQuery}
              </pre>
            </div>
          )}

          {debug?.llmPrompt && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-gray-400">LLM Prompt</span>
                <button
                  onClick={() => onCopy(debug.llmPrompt || '')}
                  className="text-accent hover:text-accent-hover"
                >
                  <Copy size={12} />
                </button>
              </div>
              <pre className="bg-dark-bg border border-dark-border rounded p-2 overflow-x-auto text-gray-300 font-mono text-xs">
                {debug.llmPrompt}
              </pre>
            </div>
          )}

          {debug?.llmResponse && (
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-gray-400">LLM Response</span>
                <button
                  onClick={() => onCopy(debug.llmResponse || '')}
                  className="text-accent hover:text-accent-hover"
                >
                  <Copy size={12} />
                </button>
              </div>
              <pre className="bg-dark-bg border border-dark-border rounded p-2 overflow-x-auto text-gray-300 font-mono text-xs">
                {debug.llmResponse}
              </pre>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default DebugPanel;
