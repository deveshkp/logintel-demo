/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // Dark mode colors (XAI-inspired)
        'dark-bg': '#0a0e27',
        'dark-surface': '#1a1f3a',
        'dark-border': '#2d3748',
        'accent': '#00d9ff',
        'accent-hover': '#00b8d4',
        'success': '#00ff88',
        'warning': '#ffaa00',
        'error': '#ff3333',
        // Light mode colors
        'light-bg': '#ffffff',
        'light-surface': '#f5f5f5',
        'light-border': '#e0e0e0',
      },
      fontFamily: {
        'sans': ['Inter', 'system-ui', 'sans-serif'],
        'mono': ['JetBrains Mono', 'Courier New', 'monospace'],
      },
      animation: {
        'pulse-subtle': 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'fade-in': 'fadeIn 0.3s ease-in',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
      },
    },
  },
  plugins: [],
}
